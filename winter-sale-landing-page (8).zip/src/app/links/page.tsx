"use client";

import { useEffect, useState } from "react";
import { OWNER_WHATSAPP_LINK, OWNER_PHONE_DISPLAY, SUGGESTED_VERCEL_URL, PRODUCT } from "@/lib/store";

type SiteUrlInfo = { envUrl: string; customUrl: string; effectiveUrl: string; suggested: string };

export default function LinksPage() {
  const [origin, setOrigin] = useState("");
  const [copied, setCopied] = useState<string | null>(null);
  const [site, setSite] = useState<SiteUrlInfo | null>(null);
  const [editUrl, setEditUrl] = useState("");
  const [saving, setSaving] = useState(false);
  const [saveMsg, setSaveMsg] = useState("");
  const [editing, setEditing] = useState(false);

  useEffect(() => {
    setOrigin(window.location.origin);
    fetch("/api/site-url")
      .then((r) => (r.ok ? r.json() : null))
      .then((d) => {
        if (d) {
          setSite(d);
          setEditUrl(d.customUrl || "");
        }
      })
      .catch(() => {});
  }, []);

  const copy = async (text: string, id: string) => {
    try {
      await navigator.clipboard.writeText(text);
    } catch {
      const ta = document.createElement("textarea");
      ta.value = text;
      document.body.appendChild(ta);
      ta.select();
      document.execCommand("copy");
      document.body.removeChild(ta);
    }
    setCopied(id);
    setTimeout(() => setCopied(null), 2000);
  };

  const saveOfficial = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    setSaveMsg("");
    try {
      const adminKey = localStorage.getItem("admin_key") || "";
      if (!adminKey) {
        setSaveMsg("❌ خاصك تدخل للوحة التحكم (/admin) أولاً باش يتحفظ المفتاح، وعاود حاول.");
        return;
      }
      const res = await fetch("/api/site-url", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ key: adminKey, url: editUrl }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "خطأ");
      setSite((s) => (s ? { ...s, customUrl: data.customUrl, effectiveUrl: data.effectiveUrl } : s));
      setSaveMsg(editUrl.trim() === "" ? "✅ تم المسح — دابا كنستعملو الرابط الحالي." : "✅ تم الحفظ! هاد هو الرابط الرسمي دابا 🎉");
      setEditing(false);
    } catch (err) {
      setSaveMsg(err instanceof Error ? `❌ ${err.message}` : "❌ خطأ");
    } finally {
      setSaving(false);
    }
  };

  // Official URL wins for sharing; fallback to current origin
  const official = site?.effectiveUrl || "";
  const storeUrl = official ? `${official}/` : origin ? `${origin}/` : "";
  const usingOfficial = Boolean(official);
  const adminUrl = origin ? `${origin}/admin` : "";
  const linksUrl = origin ? `${origin}/links` : "";
  const waNumber = OWNER_WHATSAPP_LINK.replace("https://wa.me/", "");
  const adminPass = "baytipro2026";

  const shareText = `🔥 عرض الشتاء! سخان الماء الغازي 6L عالي الجودة بـ ${PRODUCT.price} درهم فقط بدل ${PRODUCT.oldPrice} (ضمان 6 أشهر + توصيل مجاني + الدفع عند الاستلام) 👇`;

  const nativeShare = async () => {
    const text = `${shareText}\n${storeUrl}`;
    if (navigator.share) {
      try {
        await navigator.share({ title: "BaytiPro — عرض الشتاء 🔥", text, url: storeUrl });
      } catch {
        /* user cancelled */
      }
    } else {
      copy(text, "share");
    }
  };

  const btn = (id: string, label: string) =>
    copied === id ? "✅ تنسخ!" : label;

  return (
    <div dir="rtl" className="min-h-screen bg-slate-100 px-4 py-8">
      <div className="mx-auto max-w-xl">
        {/* Header */}
        <div className="winter-gradient rounded-3xl p-6 text-center text-white shadow-xl">
          <p className="text-4xl">🔗</p>
          <h1 className="mt-2 text-2xl font-black">روابط متجر BaytiPro</h1>
          <p className="mt-1 text-sm font-bold text-white/70">
            جميع الروابط فبلاصة وحدة — نسخ وشارك وخدم 👍
          </p>
        </div>

        {!origin && (
          <p className="mt-4 rounded-2xl bg-white p-4 text-center text-sm font-bold text-slate-400">
            ⏳ جاري تجهيز الروابط...
          </p>
        )}

        {origin && (
          <div className="mt-4 space-y-3">
            {/* Official BaytiPro URL */}
            <div className="rounded-2xl border-2 border-slate-900 bg-slate-950 p-4 text-white shadow-xl">
              <p className="font-black">🏠 رابط BaytiPro الرسمي {usingOfficial ? "✅" : "⏳"}</p>
              {usingOfficial ? (
                <>
                  <p dir="ltr" className="mt-2 break-all rounded-xl bg-black/40 p-3 text-left font-mono text-base font-black text-green-300">
                    {storeUrl}
                  </p>
                  <p className="mt-1 text-[11px] font-bold text-white/60">
                    هاد هو الرابط اللي كيشارك مع الزبناء فكل الأزرار لتحت ✅
                  </p>
                </>
              ) : (
                <p className="mt-2 rounded-xl bg-white/10 p-3 text-xs font-bold leading-relaxed text-white/80">
                  ما زال ما تحددش الرابط الرسمي — دابا كنستعملو الرابط المؤقت لتحت.
                  ملي تنشر الموقع على Vercel غتاخد رابط دائم بحال <b dir="ltr" className="text-green-300">{SUGGESTED_VERCEL_URL}</b> —
                  ومن بعد سجلو هنا باش يولي هو الرسمي ✅ (الشرح لتحت 👇)
                </p>
              )}
              <div className="mt-2 flex gap-2">
                <button
                  onClick={() => copy(storeUrl, "official")}
                  disabled={!storeUrl}
                  className="flex-1 rounded-xl bg-green-500 px-4 py-2.5 font-black text-white disabled:opacity-50"
                >
                  {btn("official", "📋 نسخ رابط المتجر")}
                </button>
                <button
                  onClick={() => setEditing(!editing)}
                  className="shrink-0 rounded-xl bg-white/15 px-4 py-2.5 text-sm font-black text-white ring-1 ring-white/30"
                >
                  {editing ? "إغلاق" : "⚙️ تبديل الرابط"}
                </button>
              </div>
              {editing && (
                <form onSubmit={saveOfficial} className="mt-3 space-y-2 rounded-xl bg-white/10 p-3">
                  <p className="text-xs font-bold text-white/70">
                    لصق رابط الموقع الرسمي (مثال: <b dir="ltr">{SUGGESTED_VERCEL_URL}</b>) — ولا خليه خاوي باش ترجع للرابط الحالي:
                  </p>
                  <div className="flex gap-2">
                    <input
                      value={editUrl}
                      onChange={(e) => setEditUrl(e.target.value)}
                      placeholder="https://baytipro.vercel.app"
                      dir="ltr"
                      className="flex-1 rounded-xl border-2 border-white/20 bg-black/30 px-4 py-2.5 text-left font-mono text-sm font-bold text-white outline-none placeholder:text-white/30 focus:border-green-400"
                    />
                    <button disabled={saving} className="shrink-0 rounded-xl bg-green-500 px-5 py-2.5 font-black text-white disabled:opacity-50">
                      {saving ? "..." : "💾 حفظ"}
                    </button>
                  </div>
                  <button
                    type="button"
                    onClick={() => setEditUrl(SUGGESTED_VERCEL_URL)}
                    className="text-xs font-black text-green-300 underline"
                  >
                    استعمل الرابط المقترح: {SUGGESTED_VERCEL_URL}
                  </button>
                  {saveMsg && <p className="text-xs font-black">{saveMsg}</p>}
                </form>
              )}
            </div>

            {/* Current temp link */}
            <div className="rounded-2xl border-2 border-orange-300 bg-white p-4 shadow">
              <p className="font-black">🛒 رابط صفحة البيع الحالي <span className="text-xs font-bold text-slate-400">(مؤقت — خدام دابا)</span></p>
              <p dir="ltr" className="mt-2 break-all rounded-xl bg-slate-100 p-3 text-left font-mono text-sm font-bold text-slate-800">
                {origin}/
              </p>
              <div className="mt-2 flex gap-2">
                <button
                  onClick={() => copy(`${origin}/`, "store")}
                  className="flex-1 rounded-xl bg-orange-500 px-4 py-2.5 font-black text-white"
                >
                  {btn("store", "📋 نسخ الرابط")}
                </button>
                <a
                  href={`${origin}/`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex-1 rounded-xl bg-slate-900 px-4 py-2.5 text-center font-black text-white"
                >
                  🔗 فتح المتجر
                </a>
              </div>
            </div>

            {/* How to get BaytiPro link */}
            <div className="rounded-2xl border-2 border-green-300 bg-green-50 p-4">
              <p className="font-black text-green-900">🎯 كيفاش تاخد رابط دائم باسم BaytiPro؟ (مجاني)</p>
              <ol className="mt-2 space-y-1.5 text-sm font-semibold leading-relaxed text-green-800">
                <li>1️⃣ ارفع المشروع على <b>GitHub</b> (من لوحة التحكم ← 📁 حمّل الـ ZIP ← رفعه).</li>
                <li>2️⃣ سجل فـ <b dir="ltr">vercel.com</b> بحساب GitHub ← <b dir="ltr">Add New → Project</b> ← اختار المشروع.</li>
                <li>3️⃣ <b>أهم خطوة:</b> فسمية المشروع كتب <b dir="ltr">baytipro</b> بالضبط — الرابط غيولي:
                  <span dir="ltr" className="mt-1 block rounded-lg bg-white p-2 text-center font-mono font-black text-green-700">{SUGGESTED_VERCEL_URL}</span>
                </li>
                <li>4️⃣ زيد <b dir="ltr">DATABASE_URL</b> و <b dir="ltr">ADMIN_KEY</b> وضغط <b dir="ltr">Deploy</b> 🚀</li>
                <li>5️⃣ رجع لهنا وسجّل الرابط الجديد فـ &quot;⚙️ تبديل الرابط&quot; باش يولي هو الرسمي ✅</li>
              </ol>
              <p className="mt-2 text-[11px] font-bold text-green-700">
                💡 وبغيتي احترافية أكثر؟ شري دومين <b dir="ltr">baytipro.ma</b> (~200 درهم/عام) وربطو مع Vercel — وغتسجلو هنا بنفس الطريقة!
              </p>
            </div>

            {/* Admin link */}
            <div className="rounded-2xl border-2 border-slate-300 bg-white p-4 shadow">
              <p className="font-black">🔐 رابط لوحة التحكم <span className="text-xs font-bold text-slate-400">(غير ليك — فيها الطلبات)</span></p>
              <p dir="ltr" className="mt-2 break-all rounded-xl bg-slate-100 p-3 text-left font-mono text-sm font-bold text-slate-800">
                {adminUrl}
              </p>
              <p className="mt-2 flex items-center justify-between rounded-xl bg-slate-50 p-2.5 text-sm font-bold text-slate-600 ring-1 ring-slate-200">
                <span>🔑 كلمة السر: <b dir="ltr" className="font-mono">{adminPass}</b></span>
                <button onClick={() => copy(adminPass, "pass")} className="rounded-lg bg-white px-3 py-1.5 text-xs font-black text-slate-700 shadow-sm ring-1 ring-slate-200">
                  {btn("pass", "📋 نسخ")}
                </button>
              </p>
              <div className="mt-2 flex gap-2">
                <button
                  onClick={() => copy(adminUrl, "admin")}
                  className="flex-1 rounded-xl bg-slate-700 px-4 py-2.5 font-black text-white"
                >
                  {btn("admin", "📋 نسخ الرابط")}
                </button>
                <a
                  href={adminUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex-1 rounded-xl bg-slate-900 px-4 py-2.5 text-center font-black text-white"
                >
                  🔓 فتح اللوحة
                </a>
              </div>
            </div>

            {/* WhatsApp */}
            <div className="rounded-2xl border-2 border-green-300 bg-white p-4 shadow">
              <p className="font-black">💬 رابط الواتساب ديالك <span className="text-xs font-bold text-slate-400" dir="ltr">{OWNER_PHONE_DISPLAY}</span></p>
              <p dir="ltr" className="mt-2 break-all rounded-xl bg-slate-100 p-3 text-left font-mono text-sm font-bold text-slate-800">
                {OWNER_WHATSAPP_LINK}
              </p>
              <div className="mt-2 flex gap-2">
                <button
                  onClick={() => copy(OWNER_WHATSAPP_LINK, "wa")}
                  className="flex-1 rounded-xl bg-[#25D366] px-4 py-2.5 font-black text-white"
                >
                  {btn("wa", "📋 نسخ الرابط")}
                </button>
                <a
                  href={OWNER_WHATSAPP_LINK}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex-1 rounded-xl bg-slate-900 px-4 py-2.5 text-center font-black text-white"
                >
                  💬 فتح واتساب
                </a>
              </div>
            </div>

            {/* This page */}
            <div className="rounded-2xl bg-white p-4 shadow">
              <p className="font-black">🔗 رابط هاد الصفحة (روابطي)</p>
              <div className="mt-2 flex gap-2">
                <p dir="ltr" className="flex-1 break-all rounded-xl bg-slate-100 p-3 text-left font-mono text-xs font-bold text-slate-600">
                  {linksUrl}
                </p>
                <button
                  onClick={() => copy(linksUrl, "links")}
                  className="shrink-0 rounded-xl bg-blue-600 px-4 py-2 font-black text-white"
                >
                  {btn("links", "📋 نسخ")}
                </button>
              </div>
            </div>

            {/* Share */}
            <div className="winter-gradient rounded-2xl p-4 text-white shadow">
              <p className="font-black">📤 شارك العرض مع الزبناء</p>
              <p className="mt-1 text-xs font-bold text-white/70">
                {usingOfficial ? "المشاركة غتستعمل الرابط الرسمي ✅" : "المشاركة كتستعمل الرابط الحالي (ملي تسجّل الرسمي غيتبدل أوتوماتيكياً)"} 🚀
              </p>
              <div className="mt-3 grid grid-cols-2 gap-2">
                <button
                  onClick={nativeShare}
                  className="col-span-2 rounded-xl bg-white px-4 py-3 font-black text-slate-900"
                >
                  {copied === "share" ? "✅ تنسخ النص! لصقو فين بغيتي" : "📤 مشاركة سريعة (تيليفون)"}
                </button>
                <a
                  href={`https://wa.me/?text=${encodeURIComponent(`${shareText}\n${storeUrl}`)}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="rounded-xl bg-[#25D366] px-4 py-2.5 text-center font-black text-white"
                >
                  🟢 واتساب
                </a>
                <a
                  href={`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(storeUrl)}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="rounded-xl bg-[#1877F2] px-4 py-2.5 text-center font-black text-white"
                >
                  🔵 فيسبوك
                </a>
                <a
                  href={`https://t.me/share/url?url=${encodeURIComponent(storeUrl)}&text=${encodeURIComponent(shareText)}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="rounded-xl bg-[#229ED9] px-4 py-2.5 text-center font-black text-white"
                >
                  ✈️ تيليغرام
                </a>
                <button
                  onClick={() => copy(`${shareText}\n${storeUrl}`, "adtext")}
                  className="rounded-xl bg-white/15 px-4 py-2.5 font-black text-white ring-1 ring-white/30"
                >
                  {btn("adtext", "📋 نسخ نص الإعلان")}
                </button>
              </div>
            </div>

            {/* Note */}
            <div className="rounded-2xl border-2 border-amber-300 bg-amber-50 p-4 text-sm">
              <p className="font-black text-amber-800">⏳ ملاحظة على الرابط الحالي:</p>
              <p className="mt-1 font-semibold leading-relaxed text-amber-700">
                الرابط الحالي خدام دابا 100% — بيع بيه وجرب بيه. ولكن راه مؤقت (رابط تجريبي)،
                الرابط الدائم باسم BaytiPro كيتاخد ملي تنشر على Vercel (الشرح فوق 👆 — مجاني).
              </p>
              <p className="mt-2 text-xs font-bold text-amber-600">
                💡 رقم الواتساب اللي كتوصلو الطلبات: <span dir="ltr">{waNumber}</span>
              </p>
            </div>

            <p className="pb-4 text-center text-[11px] font-bold text-slate-400">
              © 2026 BaytiPro — متجر رشيد 🏠
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
