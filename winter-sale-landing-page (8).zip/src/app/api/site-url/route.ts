import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { settings } from "@/db/schema";
import { eq } from "drizzle-orm";
import { normalizeSiteUrl } from "@/lib/store";

export const dynamic = "force-dynamic";

function adminKey(req: NextRequest): string | null {
  // key can come from query (?key=) or body ({ key })
  return req.nextUrl.searchParams.get("key");
}

function isAdminKey(key: string | null): boolean {
  const valid = process.env.ADMIN_KEY ? [process.env.ADMIN_KEY] : ["baytipro2026", "starlux2026"];
  return valid.includes(key ?? "");
}

async function readCustomUrl(): Promise<string> {
  try {
    const rows = await db.select().from(settings).where(eq(settings.key, "public_site_url")).limit(1);
    return normalizeSiteUrl(rows[0]?.value || "");
  } catch {
    return "";
  }
}

// GET /api/site-url → { envUrl, customUrl, effectiveUrl }
export async function GET() {
  try {
    const envUrl = normalizeSiteUrl(process.env.NEXT_PUBLIC_SITE_URL || "");
    const customUrl = await readCustomUrl();
    return NextResponse.json({
      envUrl,
      customUrl,
      effectiveUrl: envUrl || customUrl,
      suggested: "https://baytipro.vercel.app",
    });
  } catch (err) {
    console.error("site-url GET failed:", err);
    return NextResponse.json({ error: "حدث خطأ" }, { status: 500 });
  }
}

// POST /api/site-url { key, url } → save custom public URL (empty url = clear)
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const key: string | null = adminKey(req) || (typeof body.key === "string" ? body.key : null);
    if (!isAdminKey(key)) return NextResponse.json({ error: "غير مصرح" }, { status: 401 });

    const raw = typeof body.url === "string" ? body.url : "";
    const clean = raw.trim() === "" ? "" : normalizeSiteUrl(raw);
    if (raw.trim() !== "" && !clean) {
      return NextResponse.json({ error: "الرابط غير صحيح — مثال: https://baytipro.vercel.app" }, { status: 400 });
    }

    await db
      .insert(settings)
      .values({ key: "public_site_url", value: clean, updatedAt: new Date() })
      .onConflictDoUpdate({
        target: settings.key,
        set: { value: clean, updatedAt: new Date() },
      });

    const envUrl = normalizeSiteUrl(process.env.NEXT_PUBLIC_SITE_URL || "");
    return NextResponse.json({ success: true, customUrl: clean, effectiveUrl: envUrl || clean });
  } catch (err) {
    console.error("site-url POST failed:", err);
    return NextResponse.json({ error: "حدث خطأ" }, { status: 500 });
  }
}
