import { NextRequest, NextResponse } from "next/server";
import { readFile, stat } from "fs/promises";
import { join } from "path";

export const dynamic = "force-dynamic";

// Whitelist of exportable project files (never includes .env or secrets)
const EXPORTABLE_FILES = [
  "src/app/page.tsx",
  "src/app/layout.tsx",
  "src/app/globals.css",
  "src/app/admin/page.tsx",
  "src/app/api/health/route.ts",
  "src/app/api/orders/route.ts",
  "src/app/api/orders/status/route.ts",
  "src/app/api/orders/notify/route.ts",
  "src/app/api/whatsapp/route.ts",
  "src/app/api/source/route.ts",
  "src/app/api/source/zip/route.ts",
  "src/app/api/site-url/route.ts",
  "src/app/sitemap.ts",
  "src/app/robots.ts",
  "src/app/links/page.tsx",
  "src/components/landing.tsx",
  "src/db/index.ts",
  "src/db/schema.ts",
  "src/lib/store.ts",
  "src/lib/whatsapp.ts",
  "package.json",
  "tsconfig.json",
  "next.config.ts",
  "postcss.config.mjs",
  "drizzle.config.json",
  "eslint.config.mjs",
  ".gitignore",
  "README.md",
  ".env.example",
];

const DESCRIPTIONS: Record<string, string> = {
  "src/app/page.tsx": "🏠 الصفحة الرئيسية — كتجيب عدد طلبات اليوم وكتعرض صفحة البيع",
  "src/app/layout.tsx": "🔖 عنوان الموقع والوصف (SEO) + الخطوط العربية",
  "src/app/globals.css": "🎨 التصميم العام — الألوان والحركات (ثلج، نبض...)",
  "src/app/admin/page.tsx": "🔐 لوحة التحكم — الطلبات + الواتساب + استخراج الملفات",
  "src/app/api/health/route.ts": "💚 فحص صحة السيرفر",
  "src/app/api/orders/route.ts": "📦 إنشاء الطلبات + تنبيه الواتساب الأوتوماتيكي",
  "src/app/api/orders/status/route.ts": "🔄 تبديل حالة الطلب (مؤكد/مشحون...)",
  "src/app/api/orders/notify/route.ts": "📲 إعادة إرسال الطلب لواتساب المالك",
  "src/app/api/whatsapp/route.ts": "💬 إعدادات الواتساب (حفظ CallMeBot apikey)",
  "src/app/api/source/route.ts": "📁 استخراج ملفات المشروع (هاد الملف!)",
  "src/app/api/source/zip/route.ts": "📦 توليد ملف ZIP للرفع على GitHub",
  "src/app/api/site-url/route.ts": "🏠 حفظ الرابط الرسمي للموقع",
  "src/app/sitemap.ts": "🗺️ خريطة الموقع (SEO)",
  "src/app/robots.ts": "🤖 ملف robots (SEO)",
  "src/app/links/page.tsx": "🔗 صفحة روابطي — المشاركة والرابط الرسمي",
  "src/components/landing.tsx": "🔥 صفحة البيع كاملة — العرض + الاستمارة + الآراء",
  "src/db/index.ts": "🔌 الاتصال بقاعدة البيانات",
  "src/db/schema.ts": "🗄️ جداول قاعدة البيانات (الطلبات + الإعدادات)",
  "src/lib/store.ts": "⚙️ إعدادات المتجر — الثمن، المدن، العروض",
  "src/lib/whatsapp.ts": "💬 مكتبة الواتساب — الرسائل + الإرسال",
  "package.json": "📦 لائحة المكتبات + أوامر التشغيل",
  "tsconfig.json": "📝 إعدادات TypeScript",
  "next.config.ts": "⚡ إعدادات Next.js",
  "postcss.config.mjs": "🎨 إعدادات Tailwind CSS",
  "drizzle.config.json": "🗄️ إعدادات Drizzle (قاعدة البيانات)",
  "eslint.config.mjs": "✅ إعدادات فحص الكود",
  ".gitignore": "🚫 حماية المفاتيح من الرفع لـ GitHub",
  "README.md": "📖 دليل المشروع والنشر",
  ".env.example": "🔑 مثال المفاتيح (كيترفع) — الحقيقي لا!",
};

function isAdmin(req: NextRequest): boolean {
  const key = req.nextUrl.searchParams.get("key");
  const valid = process.env.ADMIN_KEY ? [process.env.ADMIN_KEY] : ["baytipro2026", "starlux2026"];
  return valid.includes(key ?? "");
}

// GET /api/source?key=... → list of files with metadata (no content)
// GET /api/source?key=...&file=src/lib/store.ts → single file content
// GET /api/source?key=...&bundle=1 → all files content (for download-all)
export async function GET(req: NextRequest) {
  try {
    if (!isAdmin(req)) return NextResponse.json({ error: "غير مصرح" }, { status: 401 });

    const fileParam = req.nextUrl.searchParams.get("file");
    const bundle = req.nextUrl.searchParams.get("bundle") === "1";
    const root = process.cwd();

    // Single file
    if (fileParam) {
      if (!EXPORTABLE_FILES.includes(fileParam)) {
        return NextResponse.json({ error: "ملف غير مسموح" }, { status: 400 });
      }
      const content = await readFile(join(root, fileParam), "utf-8");
      const lines = content.split("\n").length;
      return NextResponse.json({
        path: fileParam,
        content,
        lines,
        description: DESCRIPTIONS[fileParam] ?? "",
      });
    }

    // Full bundle
    if (bundle) {
      const files = [];
      for (const p of EXPORTABLE_FILES) {
        try {
          const content = await readFile(join(root, p), "utf-8");
          files.push({ path: p, content, lines: content.split("\n").length });
        } catch {
          files.push({ path: p, content: "", lines: 0, missing: true });
        }
      }
      return NextResponse.json({ files, exportedAt: new Date().toISOString() });
    }

    // List with metadata
    const files = [];
    for (const p of EXPORTABLE_FILES) {
      try {
        const s = await stat(join(root, p));
        files.push({
          path: p,
          size: s.size,
          description: DESCRIPTIONS[p] ?? "",
        });
      } catch {
        files.push({ path: p, size: 0, description: DESCRIPTIONS[p] ?? "", missing: true });
      }
    }
    return NextResponse.json({ files });
  } catch (err) {
    console.error("Source export failed:", err);
    return NextResponse.json({ error: "حدث خطأ" }, { status: 500 });
  }
}
