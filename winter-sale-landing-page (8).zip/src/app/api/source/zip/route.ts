import { NextRequest } from "next/server";
import { readFile } from "fs/promises";
import { join } from "path";
import JSZip from "jszip";

export const dynamic = "force-dynamic";
export const maxDuration = 60;

// Text files with their exact GitHub paths
const TEXT_FILES = [
  "src/app/page.tsx",
  "src/app/layout.tsx",
  "src/app/globals.css",
  "src/app/admin/page.tsx",
  "src/app/api/health/route.ts",
  "src/app/api/orders/route.ts",
  "src/app/api/orders/status/route.ts",
  "src/app/api/orders/notify/route.ts",
  "src/app/api/whatsapp/route.ts",
  "src/app/api/source/route.ts",
  "src/app/api/source/zip/route.ts",
  "src/app/api/site-url/route.ts",
  "src/app/sitemap.ts",
  "src/app/robots.ts",
  "src/app/links/page.tsx",
  "src/components/landing.tsx",
  "src/db/index.ts",
  "src/db/schema.ts",
  "src/lib/store.ts",
  "src/lib/whatsapp.ts",
  "package.json",
  "tsconfig.json",
  "next.config.ts",
  "postcss.config.mjs",
  "drizzle.config.json",
  "eslint.config.mjs",
  ".gitignore",
  "README.md",
  ".env.example",
];

// Binary files (images)
const IMAGE_FILES = [
  "public/images/heater-hero.png",
  "public/images/heater-bathroom.jpg",
  "public/images/hot-shower.jpg",
];

function isAdmin(req: NextRequest): boolean {
  const key = req.nextUrl.searchParams.get("key");
  const valid = process.env.ADMIN_KEY ? [process.env.ADMIN_KEY] : ["baytipro2026", "starlux2026"];
  return valid.includes(key ?? "");
}

// GET /api/source/zip?key=... → downloads baytipro-github.zip
export async function GET(req: NextRequest) {
  try {
    if (!isAdmin(req)) {
      return new Response(JSON.stringify({ error: "غير مصرح" }), {
        status: 401,
        headers: { "Content-Type": "application/json" },
      });
    }

    const root = process.cwd();
    const zip = new JSZip();
    const missing: string[] = [];

    // Add text files preserving folder structure
    for (const p of TEXT_FILES) {
      try {
        const content = await readFile(join(root, p), "utf-8");
        zip.file(`baytipro/${p}`, content);
      } catch {
        missing.push(p);
      }
    }

    // Add images preserving folder structure
    for (const p of IMAGE_FILES) {
      try {
        const buf = await readFile(join(root, p));
        zip.file(`baytipro/${p}`, buf);
      } catch {
        missing.push(p);
      }
    }

    // Add a guide file inside the zip
    const guide = `# BaytiPro — كيفاش ترفع المشروع على GitHub؟

## الطريقة 1: من المتصفح (ساهلة — بلا برامج) ✅
1. فك الضغط على هاد الملف ZIP — غتلقى مجلد سميتو baytipro
2. سير لـ github.com ودير حساب (إلا ما عندكش)
3. ضغط زر + الخضر لفوق ← New repository
4. سميه: baytipro ← خليه Public ← ضغط Create repository
5. غتشوف زر أزرق "uploading an existing file" — ضغط عليه
6. حل مجلد baytipro فالحاسوب، سليكتي جميع الملفات والمجلدات اللي لداخل
   (src و public و package.json ...) وجرّهم للمتصفح
7. لتحت ضغط Commit changes ✅ صافي!

## الطريقة 2: بـ Git (للمحترفين)
  cd baytipro
  git init
  git add .
  git commit -m "BaytiPro store"
  git branch -M main
  git remote add origin https://github.com/USERNAME/baytipro.git
  git push -u origin main

## من بعد: النشر على Vercel
1. سجل في vercel.com بحساب GitHub
2. Add New → Project → اختار baytipro
3. زيد Environment Variables:
   DATABASE_URL = رابط Neon
   ADMIN_KEY = baytipro2026
4. Deploy 🚀

## ⚠️ مهم
- ملف .env الحقيقي ما كاينش هنا عن قصد — المفاتيح كتحطها فـ Vercel مباشرة
- استعمل .env.example كمرجع فالحاسوب ديالك

التاريخ: ${new Date().toLocaleString("fr-MA")}
${missing.length > 0 ? `\nملفات ناقصة: ${missing.join(", ")}` : "جميع الملفات موجودة ✅"}
`;
    zip.file("baytipro/0-اقرأني-أولا-ARFA3NI.txt", guide);

    const buffer = await zip.generateAsync({
      type: "nodebuffer",
      compression: "DEFLATE",
      compressionOptions: { level: 6 },
    });

    return new Response(new Uint8Array(buffer), {
      status: 200,
      headers: {
        "Content-Type": "application/zip",
        "Content-Disposition": `attachment; filename="baytipro-github.zip"`,
        "Content-Length": String(buffer.length),
      },
    });
  } catch (err) {
    console.error("ZIP export failed:", err);
    return new Response(JSON.stringify({ error: "حدث خطأ أثناء إنشاء الملف" }), {
      status: 500,
      headers: { "Content-Type": "application/json" },
    });
  }
}
