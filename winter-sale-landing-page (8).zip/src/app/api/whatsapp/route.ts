import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { settings } from "@/db/schema";
import { getWhatsAppStatus, sendOwnerTestMessage } from "@/lib/whatsapp";

function isAdmin(req: NextRequest): boolean {
  const key = req.nextUrl.searchParams.get("key");
  const valid = process.env.ADMIN_KEY ? [process.env.ADMIN_KEY] : ["baytipro2026", "starlux2026"];
  return valid.includes(key ?? "");
}

async function saveSetting(key: string, value: string) {
  await db
    .insert(settings)
    .values({ key, value, updatedAt: new Date() })
    .onConflictDoUpdate({
      target: settings.key,
      set: { value, updatedAt: new Date() },
    });
}

// GET: status of WhatsApp auto-send configuration
export async function GET(req: NextRequest) {
  try {
    if (!isAdmin(req)) return NextResponse.json({ error: "غير مصرح" }, { status: 401 });
    const status = await getWhatsAppStatus();
    return NextResponse.json(status);
  } catch (err) {
    console.error("WhatsApp status failed:", err);
    return NextResponse.json({ error: "حدث خطأ" }, { status: 500 });
  }
}

// POST:
// - { test: true } → send a test message to the owner via configured methods
// - { apikey } → save CallMeBot key (owner notif)
// - { ultramsg_instance, ultramsg_token } → save UltraMsg (customer + owner fallback)
export async function POST(req: NextRequest) {
  try {
    if (!isAdmin(req)) return NextResponse.json({ error: "غير مصرح" }, { status: 401 });
    const body = await req.json();

    if (body.test === true) {
      const { results } = await sendOwnerTestMessage();
      return NextResponse.json({ success: true, results });
    }

    const { apikey, ultramsg_instance, ultramsg_token } = body;

    let saved: string[] = [];

    if (typeof apikey === "string" && apikey.trim().length >= 3) {
      await saveSetting("callmebot_apikey", apikey.trim());
      saved.push("callmebot");
    }

    const instance = typeof ultramsg_instance === "string" ? ultramsg_instance.trim() : "";
    const token = typeof ultramsg_token === "string" ? ultramsg_token.trim() : "";
    if (instance || token) {
      if (instance.length < 3 || token.length < 3) {
        return NextResponse.json(
          { error: "المرجو إدخال instance id والـ token بجوج" },
          { status: 400 }
        );
      }
      await saveSetting("ultramsg_instance", instance);
      await saveSetting("ultramsg_token", token);
      saved.push("ultramsg");
    }

    if (saved.length === 0) {
      return NextResponse.json({ error: "المرجو إدخال مفتاح صحيح" }, { status: 400 });
    }
    const status = await getWhatsAppStatus();
    return NextResponse.json({ success: true, saved, status });
  } catch (err) {
    console.error("Save apikey failed:", err);
    return NextResponse.json({ error: "حدث خطأ" }, { status: 500 });
  }
}
