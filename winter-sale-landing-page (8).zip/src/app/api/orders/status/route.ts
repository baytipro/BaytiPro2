import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { orders } from "@/db/schema";
import { eq } from "drizzle-orm";

const ALLOWED = ["pending", "confirmed", "shipped", "delivered", "cancelled"];

export async function PATCH(req: NextRequest) {
  try {
    const key = req.nextUrl.searchParams.get("key");
    const validKeys = process.env.ADMIN_KEY ? [process.env.ADMIN_KEY] : ["baytipro2026", "starlux2026"];
    if (!validKeys.includes(key ?? "")) {
      return NextResponse.json({ error: "غير مصرح" }, { status: 401 });
    }
    const { id, status } = await req.json();
    if (!id || !ALLOWED.includes(status)) {
      return NextResponse.json({ error: "بيانات غير صالحة" }, { status: 400 });
    }
    await db.update(orders).set({ status }).where(eq(orders.id, Number(id)));
    return NextResponse.json({ success: true });
  } catch (err) {
    console.error("Status update failed:", err);
    return NextResponse.json({ error: "حدث خطأ" }, { status: 500 });
  }
}
