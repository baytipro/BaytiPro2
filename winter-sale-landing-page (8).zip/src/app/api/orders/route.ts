import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { orders } from "@/db/schema";
import { desc, eq, sql } from "drizzle-orm";
import { QUANTITY_OFFERS, isValidMoroccanPhone } from "@/lib/store";
import { notifyOwnerOnWhatsApp, notifyCustomerOnWhatsApp } from "@/lib/whatsapp";

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { fullName, phone, city, address, quantity, notes } = body;

    if (!fullName || typeof fullName !== "string" || fullName.trim().length < 3) {
      return NextResponse.json({ error: "المرجو إدخال الاسم الكامل" }, { status: 400 });
    }
    if (!phone || !isValidMoroccanPhone(String(phone))) {
      return NextResponse.json(
        { error: "المرجو إدخال رقم هاتف مغربي صحيح (مثال: 0612345678)" },
        { status: 400 }
      );
    }
    if (!city || typeof city !== "string" || city.trim().length < 2) {
      return NextResponse.json({ error: "المرجو اختيار المدينة" }, { status: 400 });
    }
    if (!address || typeof address !== "string" || address.trim().length < 5) {
      return NextResponse.json({ error: "المرجو إدخال العنوان الكامل" }, { status: 400 });
    }

    const qty = Math.min(Math.max(parseInt(String(quantity)) || 1, 1), 10);
    const offer = QUANTITY_OFFERS.find((o) => o.qty === qty);
    const totalPrice = offer ? offer.price : qty * 890;

    const [created] = await db
      .insert(orders)
      .values({
        fullName: fullName.trim(),
        phone: String(phone).trim(),
        city: city.trim(),
        address: address.trim(),
        quantity: qty,
        totalPrice,
        notes: notes ? String(notes).slice(0, 500) : null,
        status: "pending",
      })
      .returning();

    const info = {
      id: created.id,
      fullName: created.fullName,
      phone: created.phone,
      city: created.city,
      address: created.address,
      quantity: created.quantity,
      totalPrice: created.totalPrice,
    };

    // Notify owner on WhatsApp (never blocks the order if it fails)
    let whatsappSent = false;
    let waLink = "";
    try {
      const result = await notifyOwnerOnWhatsApp(info);
      whatsappSent = result.sent;
      waLink = result.waLink;
      if (result.sent) {
        await db.update(orders).set({ whatsappSent: true }).where(eq(orders.id, created.id));
      }
    } catch (e) {
      console.error("WhatsApp owner notify error:", e);
    }

    // Send automatic confirmation TO the customer from owner's number (never blocks)
    let customerWhatsappSent = false;
    try {
      const cResult = await notifyCustomerOnWhatsApp(info);
      customerWhatsappSent = cResult.sent;
      if (cResult.sent) {
        await db
          .update(orders)
          .set({ customerWhatsappSent: true })
          .where(eq(orders.id, created.id));
      }
    } catch (e) {
      console.error("WhatsApp customer notify error:", e);
    }

    return NextResponse.json(
      {
        success: true,
        order: created,
        whatsappSent,
        customerWhatsappSent,
        waLink,
        message: "تم استلام طلبك بنجاح!",
      },
      { status: 201 }
    );
  } catch (err) {
    console.error("Order creation failed:", err);
    return NextResponse.json({ error: "حدث خطأ، المرجو المحاولة مرة أخرى" }, { status: 500 });
  }
}

export async function GET(req: NextRequest) {
  try {
    const key = req.nextUrl.searchParams.get("key");
    const validKeys = process.env.ADMIN_KEY ? [process.env.ADMIN_KEY] : ["baytipro2026", "starlux2026"];
    if (!validKeys.includes(key ?? "")) {
      return NextResponse.json({ error: "غير مصرح" }, { status: 401 });
    }
    const all = await db.select().from(orders).orderBy(desc(orders.createdAt)).limit(500);
    const stats = await db
      .select({
        total: sql<number>`count(*)::int`,
        revenue: sql<number>`coalesce(sum(${orders.totalPrice}),0)::int`,
        pending: sql<number>`count(*) filter (where ${orders.status} = 'pending')::int`,
      })
      .from(orders);
    return NextResponse.json({ orders: all, stats: stats[0] });
  } catch (err) {
    console.error("Fetch orders failed:", err);
    return NextResponse.json({ error: "حدث خطأ" }, { status: 500 });
  }
}
