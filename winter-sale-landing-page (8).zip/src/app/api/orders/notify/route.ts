import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { orders } from "@/db/schema";
import { eq } from "drizzle-orm";
import {
  buildOwnerWaLink,
  buildCustomerWaLink,
  formatOwnerMessage,
  formatCustomerMessage,
  notifyOwnerOnWhatsApp,
  notifyCustomerOnWhatsApp,
} from "@/lib/whatsapp";

function isAdmin(req: NextRequest): boolean {
  const key = req.nextUrl.searchParams.get("key");
  const valid = process.env.ADMIN_KEY ? [process.env.ADMIN_KEY] : ["baytipro2026", "starlux2026"];
  return valid.includes(key ?? "");
}

// POST: resend WhatsApp notification for an order { id, target?: 'owner' | 'customer' }
export async function POST(req: NextRequest) {
  try {
    if (!isAdmin(req)) return NextResponse.json({ error: "غير مصرح" }, { status: 401 });
    const { id, target } = await req.json();
    if (!id) return NextResponse.json({ error: "ناقص رقم الطلب" }, { status: 400 });
    const toCustomer = target === "customer";

    const rows = await db.select().from(orders).where(eq(orders.id, Number(id))).limit(1);
    const order = rows[0];
    if (!order) return NextResponse.json({ error: "الطلب غير موجود" }, { status: 404 });

    const info = {
      id: order.id,
      fullName: order.fullName,
      phone: order.phone,
      city: order.city,
      address: order.address,
      quantity: order.quantity,
      totalPrice: order.totalPrice,
    };

    if (toCustomer) {
      const result = await notifyCustomerOnWhatsApp(info);
      if (result.sent) {
        await db
          .update(orders)
          .set({ customerWhatsappSent: true })
          .where(eq(orders.id, order.id));
      }
      return NextResponse.json({
        ...result,
        target: "customer",
        message: formatCustomerMessage(info),
        orderId: order.id,
      });
    }

    const result = await notifyOwnerOnWhatsApp(info);
    if (result.sent) {
      await db.update(orders).set({ whatsappSent: true }).where(eq(orders.id, order.id));
    }
    return NextResponse.json({
      ...result,
      target: "owner",
      message: formatOwnerMessage(info),
      orderId: order.id,
    });
  } catch (err) {
    console.error("Notify failed:", err);
    return NextResponse.json({ error: "حدث خطأ" }, { status: 500 });
  }
}

// GET: get wa.me link + message preview for an order ?id=&key=&target=owner|customer
export async function GET(req: NextRequest) {
  try {
    if (!isAdmin(req)) return NextResponse.json({ error: "غير مصرح" }, { status: 401 });
    const id = req.nextUrl.searchParams.get("id");
    const toCustomer = req.nextUrl.searchParams.get("target") === "customer";
    if (!id) return NextResponse.json({ error: "ناقص رقم الطلب" }, { status: 400 });
    const rows = await db.select().from(orders).where(eq(orders.id, Number(id))).limit(1);
    const order = rows[0];
    if (!order) return NextResponse.json({ error: "الطلب غير موجود" }, { status: 404 });
    const info = {
      id: order.id,
      fullName: order.fullName,
      phone: order.phone,
      city: order.city,
      address: order.address,
      quantity: order.quantity,
      totalPrice: order.totalPrice,
    };
    if (toCustomer) {
      return NextResponse.json({ waLink: buildCustomerWaLink(info), message: formatCustomerMessage(info) });
    }
    return NextResponse.json({ waLink: buildOwnerWaLink(info), message: formatOwnerMessage(info) });
  } catch (err) {
    console.error("Notify link failed:", err);
    return NextResponse.json({ error: "حدث خطأ" }, { status: 500 });
  }
}
