"use client";

import { useEffect, useState } from "react";

type Order = {
  id: number;
  fullName: string;
  phone: string;
  city: string;
  address: string;
  quantity: number;
  totalPrice: number;
  status: string;
  notes: string | null;
  whatsappSent: boolean;
  customerWhatsappSent: boolean;
  createdAt: string;
};

type WaStatus = { meta: boolean; callmebot: boolean; ultramsg: boolean; customerReady: boolean; ownerReady: boolean; owner: string };

type TestResult = { method: string; label: string; sent: boolean; detail: string };

const CALLMEBOT_NUM = "+34 684 770 005";
const CALLMEBOT_TEXT = "I allow callmebot to send me messages";
const CALLMEBOT_LINK = `https://wa.me/34684770005?text=${encodeURIComponent(CALLMEBOT_TEXT)}`;

const STATUS_LABELS: Record<string, { label: string; color: string }> = {
  pending: { label: "⏳ جديد", color: "bg-amber-100 text-amber-800" },
  confirmed: { label: "✅ مؤكد", color: "bg-blue-100 text-blue-800" },
  shipped: { label: "🚚 مشحون", color: "bg-purple-100 text-purple-800" },
  delivered: { label: "📦 تم التوصيل", color: "bg-green-100 text-green-800" },
  cancelled: { label: "❌ ملغي", color: "bg-red-100 text-red-800" },
};

const OWNER_INTL = "212651840540";

function toIntl(phone: string): string {
  const c = phone.replace(/[\s-]/g, "");
  if (c.startsWith("+212")) return c.slice(1);
  if (c.startsWith("212")) return c;
  if (c.startsWith("0")) return "212" + c.slice(1);
  return c;
}

function ownerWaLink(o: Order): string {
  const msg = `🔥 *طلب جديد! — سخان الغاز 6L (BaytiPro)*\n━━━━━━━━━━━━━━\n🧾 رقم الطلب: *#${o.id}*\n👤 الاسم: ${o.fullName}\n📞 الهاتف: ${o.phone}\n📍 المدينة: ${o.city}\n🏠 العنوان: ${o.address}\n🔢 الكمية: ${o.quantity}\n💰 المجموع: *${o.totalPrice} درهم*`;
  return `https://wa.me/${OWNER_INTL}?text=${encodeURIComponent(msg)}`;
}

function customerWaLink(o: Order): string {
  const msg = [
    `السلام عليكم ${o.fullName} 👋`,
    "",
    "شكراً على الثقة ديالك! توصلنا بالطلب ديالك بنجاح 🎉",
    "",
    "🧾 تفاصيل الطلب:",
    `▪️ رقم الطلب: #${o.id}`,
    `▪️ المنتوج: سخان الماء الغازي الفوري 6L ⭐`,
    `▪️ الكمية: ${o.quantity}`,
    `▪️ المجموع عند الاستلام: ${o.totalPrice} درهم 💰`,
    `▪️ المدينة: ${o.city}`,
    "",
    "غادي نتصلو بيك قريباً باش نأكدو الطلب، ومن بعد كنصيفطو السلعة حتى لباب الدار 🚚",
    "— BaytiPro | متجر رشيد 🏠",
  ].join("\n");
  return `https://wa.me/${toIntl(o.phone)}?text=${encodeURIComponent(msg)}`;
}

type SourceFile = { path: string; size: number; description: string; missing?: boolean };

function SourceFiles({ adminKey }: { adminKey: string }) {
  const [open, setOpen] = useState(false);
  const [files, setFiles] = useState<SourceFile[]>([]);
  const [loading, setLoading] = useState(false);
  const [viewing, setViewing] = useState<{ path: string; content: string; lines: number } | null>(null);
  const [loadingFile, setLoadingFile] = useState<string | null>(null);
  const [copied, setCopied] = useState<string | null>(null);
  const [bundleLoading, setBundleLoading] = useState(false);
  const [zipLoading, setZipLoading] = useState(false);

  const loadList = async () => {
    setLoading(true);
    try {
      const res = await fetch(`/api/source?key=${encodeURIComponent(adminKey)}`);
      const data = await res.json();
      if (res.ok) setFiles(data.files);
    } finally {
      setLoading(false);
    }
  };

  const toggle = () => {
    const next = !open;
    setOpen(next);
    if (next && files.length === 0) loadList();
  };

  const viewFile = async (path: string) => {
    if (viewing?.path === path) {
      setViewing(null);
      return;
    }
    setLoadingFile(path);
    try {
      const res = await fetch(`/api/source?key=${encodeURIComponent(adminKey)}&file=${encodeURIComponent(path)}`);
      const data = await res.json();
      if (res.ok) setViewing({ path: data.path, content: data.content, lines: data.lines });
    } finally {
      setLoadingFile(null);
    }
  };

  const copyFile = async (path: string, content?: string) => {
    let text: string | undefined = content;
    if (!text) {
      const res = await fetch(`/api/source?key=${encodeURIComponent(adminKey)}&file=${encodeURIComponent(path)}`);
      const data = (await res.json()) as { content?: unknown };
      if (!res.ok || typeof data.content !== "string") return;
      text = data.content;
    }
    await navigator.clipboard.writeText(text as string);
    setCopied(path);
    setTimeout(() => setCopied(null), 2000);
  };

  const downloadFile = async (path: string, content?: string) => {
    let text: string | undefined = content;
    if (!text) {
      const res = await fetch(`/api/source?key=${encodeURIComponent(adminKey)}&file=${encodeURIComponent(path)}`);
      const data = (await res.json()) as { content?: unknown };
      if (!res.ok || typeof data.content !== "string") return;
      text = data.content;
    }
    const blob = new Blob([text as string], { type: "text/plain;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = path.replaceAll("/", "_");
    a.click();
    URL.revokeObjectURL(url);
  };

  const downloadAll = async () => {
    setBundleLoading(true);
    try {
      const res = await fetch(`/api/source?key=${encodeURIComponent(adminKey)}&bundle=1`);
      const data = await res.json();
      if (!res.ok) return;
      let bundle = `# BaytiPro — نسخة ملفات المشروع\n# التاريخ: ${new Date().toLocaleString("fr-MA")}\n# عدد الملفات: ${data.files.length}\n`;
      for (const f of data.files) {
        bundle += `\n\n${"=".repeat(70)}\n# FILE: ${f.path} (${f.lines} سطر)\n${"=".repeat(70)}\n\n${f.content}`;
      }
      const blob = new Blob([bundle], { type: "text/plain;charset=utf-8" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = "baytipro-source-bundle.txt";
      a.click();
      URL.revokeObjectURL(url);
    } finally {
      setBundleLoading(false);
    }
  };

  const downloadZip = async () => {
    setZipLoading(true);
    try {
      const res = await fetch(`/api/source/zip?key=${encodeURIComponent(adminKey)}`);
      if (!res.ok) return;
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = "baytipro-github.zip";
      a.click();
      URL.revokeObjectURL(url);
    } finally {
      setZipLoading(false);
    }
  };

  const formatSize = (b: number) => (b < 1024 ? `${b} B` : `${(b / 1024).toFixed(1)} KB`);

  return (
    <div className="mt-4 rounded-2xl border-2 border-slate-300 bg-white p-4 shadow">
      <button onClick={toggle} className="flex w-full items-center justify-between text-right">
        <span className="font-black">📁 استخراج ملفات المشروع (src + الإعدادات)</span>
        <span className="rounded-full bg-slate-900 px-3 py-1 text-xs font-black text-white">
          {open ? "إخفاء ▲" : "عرض ▼"}
        </span>
      </button>
      {open && (
        <div className="mt-3 space-y-3">
          {/* GitHub ZIP — main action */}
          <div className="rounded-xl border-2 border-slate-900 bg-slate-950 p-4 text-white">
            <p className="font-black">🚀 بغيتي ترفع المشروع على GitHub؟ حمّل ملف ZIP مقسّم بالمجلدات:</p>
            <div dir="ltr" className="mt-2 rounded-lg bg-black/40 p-3 font-mono text-[11px] leading-relaxed text-green-300">
              📦 baytipro-github.zip<br />
              └─ 📁 baytipro/<br />
              &nbsp;&nbsp;&nbsp;├─ 📁 src/ <span className="text-white/50">(app, components, db, lib)</span><br />
              &nbsp;&nbsp;&nbsp;├─ 📁 public/images/ <span className="text-white/50">(صور المنتوج)</span><br />
              &nbsp;&nbsp;&nbsp;├─ 📄 package.json + configs<br />
              &nbsp;&nbsp;&nbsp;├─ 📄 .gitignore + README.md + .env.example<br />
              &nbsp;&nbsp;&nbsp;└─ 📄 0-اقرأني-أولا (دليل الرفع)
            </div>
            <button
              onClick={downloadZip}
              disabled={zipLoading}
              className="mt-3 w-full rounded-xl bg-green-500 px-4 py-3 text-sm font-black text-white shadow-lg transition hover:bg-green-400 disabled:opacity-50"
            >
              {zipLoading ? "⏳ جاري تجهيز الملف..." : "📦 تحميل baytipro-github.zip"}
            </button>
            <details className="mt-2 text-xs font-bold text-white/70">
              <summary className="cursor-pointer text-white">📖 كيفاش ترفعو على GitHub؟ (خطوة بخطوة)</summary>
              <ol className="mt-2 space-y-1.5 leading-relaxed">
                <li>1️⃣ فك الضغط على ZIP — غتلقى مجلد <b dir="ltr">baytipro</b></li>
                <li>2️⃣ سير لـ <b dir="ltr">github.com</b> ← زر <b>+</b> ← <b dir="ltr">New repository</b></li>
                <li>3️⃣ سميه <b dir="ltr">baytipro</b> ← خليه Public ← <b dir="ltr">Create repository</b></li>
                <li>4️⃣ ضغط <b dir="ltr">uploading an existing file</b></li>
                <li>5️⃣ حل مجلد baytipro، سليكتي <b>كلشي لداخل</b> (src + public + الملفات) وجرّهم للمتصفح</li>
                <li>6️⃣ لتحت ضغط <b dir="ltr">Commit changes</b> ✅ صافي!</li>
              </ol>
              <p className="mt-2 rounded-lg bg-white/10 p-2">🔐 ملف <b dir="ltr">.env</b> ما كاينش فالـ ZIP عن قصد — المفاتيح كتحطها فـ Vercel مباشرة.</p>
            </details>
          </div>

          <div className="flex flex-wrap items-center gap-2 rounded-xl bg-slate-50 p-3 text-xs font-bold text-slate-600">
            <span>💡 ولا شوف أي ملف بوحدو، نسخو، ولا حمّلو:</span>
            <button
              onClick={downloadAll}
              disabled={bundleLoading}
              className="mr-auto rounded-lg bg-white px-4 py-2 text-xs font-black text-slate-700 shadow-sm ring-1 ring-slate-200 disabled:opacity-50"
            >
              {bundleLoading ? "⏳..." : "📄 تحميل الكل كنص (.txt)"}
            </button>
          </div>
          {loading ? (
            <p className="p-4 text-center text-sm font-bold text-slate-400">جاري التحميل...</p>
          ) : (
            <div className="mt-2 space-y-2">
              {files.map((f) => (
                <div key={f.path} className="overflow-hidden rounded-xl border border-slate-200">
                  <div className="flex flex-wrap items-center gap-2 bg-slate-50 p-2.5">
                    <button onClick={() => viewFile(f.path)} className="flex-1 text-right">
                      <span dir="ltr" className="block font-mono text-xs font-black text-slate-800">{f.path}</span>
                      <span className="block text-[11px] font-bold text-slate-500">{f.description} • {formatSize(f.size)}</span>
                    </button>
                    <button
                      onClick={() => viewFile(f.path)}
                      className="rounded-lg bg-white px-3 py-1.5 text-xs font-black text-slate-700 shadow-sm ring-1 ring-slate-200"
                    >
                      {loadingFile === f.path ? "⏳" : viewing?.path === f.path ? "إخفاء" : "👁️ عرض"}
                    </button>
                    <button
                      onClick={() => copyFile(f.path, viewing?.path === f.path ? viewing.content : undefined)}
                      className="rounded-lg bg-blue-600 px-3 py-1.5 text-xs font-black text-white"
                    >
                      {copied === f.path ? "✅ تنسخ!" : "📋 نسخ"}
                    </button>
                    <button
                      onClick={() => downloadFile(f.path, viewing?.path === f.path ? viewing.content : undefined)}
                      className="rounded-lg bg-green-600 px-3 py-1.5 text-xs font-black text-white"
                    >
                      ⬇️ تحميل
                    </button>
                  </div>
                  {viewing?.path === f.path && (
                    <pre dir="ltr" className="max-h-96 overflow-auto bg-slate-950 p-4 text-left font-mono text-[11px] leading-relaxed text-green-300">
                      {viewing.content}
                    </pre>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}

export default function AdminPage() {
  const [key, setKey] = useState("");
  const [authed, setAuthed] = useState(false);
  const [orders, setOrders] = useState<Order[]>([]);
  const [stats, setStats] = useState({ total: 0, revenue: 0, pending: 0 });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [filter, setFilter] = useState("all");
  const [wa, setWa] = useState<WaStatus | null>(null);
  const [apikey, setApikey] = useState("");
  const [savingKey, setSavingKey] = useState(false);
  const [keyMsg, setKeyMsg] = useState("");
  const [notifying, setNotifying] = useState<number | null>(null);
  const [notifyMsg, setNotifyMsg] = useState("");
  const [ultraInstance, setUltraInstance] = useState("");
  const [ultraToken, setUltraToken] = useState("");
  const [savingUltra, setSavingUltra] = useState(false);
  const [ultraMsg, setUltraMsg] = useState("");
  const [notifyingCustomer, setNotifyingCustomer] = useState<number | null>(null);
  const [testing, setTesting] = useState(false);
  const [testResults, setTestResults] = useState<TestResult[] | null>(null);
  const [copiedTxt, setCopiedTxt] = useState<string | null>(null);

  const copyTxt = async (text: string, id: string) => {
    try {
      await navigator.clipboard.writeText(text);
    } catch {
      const ta = document.createElement("textarea");
      ta.value = text;
      document.body.appendChild(ta);
      ta.select();
      document.execCommand("copy");
      document.body.removeChild(ta);
    }
    setCopiedTxt(id);
    setTimeout(() => setCopiedTxt(null), 2000);
  };

  const sendTest = async () => {
    setTesting(true);
    setTestResults(null);
    try {
      const res = await fetch(`/api/whatsapp?key=${encodeURIComponent(key)}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ test: true }),
      });
      const data = await res.json();
      if (res.ok && Array.isArray(data.results)) {
        setTestResults(data.results);
      } else {
        setTestResults([{ method: "error", label: "خطأ", sent: false, detail: data.error || "خطأ غير معروف" }]);
      }
    } catch {
      setTestResults([{ method: "error", label: "خطأ", sent: false, detail: "تعذر الاتصال بالسيرفر" }]);
    } finally {
      setTesting(false);
    }
  };

  const load = async (k: string) => {
    setLoading(true);
    setError("");
    try {
      const res = await fetch(`/api/orders?key=${encodeURIComponent(k)}`);
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "خطأ");
      setOrders(data.orders);
      setStats(data.stats);
      setAuthed(true);
      const ws = await fetch(`/api/whatsapp?key=${encodeURIComponent(k)}`);
      if (ws.ok) setWa(await ws.json());
    } catch (e) {
      setError(e instanceof Error ? e.message : "خطأ");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    const saved = localStorage.getItem("admin_key");
    if (saved) {
      setKey(saved);
      load(saved);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const login = (e: React.FormEvent) => {
    e.preventDefault();
    localStorage.setItem("admin_key", key);
    load(key);
  };

  const updateStatus = async (id: number, status: string) => {
    await fetch(`/api/orders/status?key=${encodeURIComponent(key)}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id, status }),
    });
    setOrders((prev) => prev.map((o) => (o.id === id ? { ...o, status } : o)));
  };

  const saveApikey = async (e: React.FormEvent) => {
    e.preventDefault();
    setSavingKey(true);
    setKeyMsg("");
    try {
      const res = await fetch(`/api/whatsapp?key=${encodeURIComponent(key)}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ apikey }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "خطأ");
      setKeyMsg("✅ تم الحفظ! دابا الطلبات غادي توصلك أوتوماتيكياً فواتساب 🎉");
      setApikey("");
      const ws = await fetch(`/api/whatsapp?key=${encodeURIComponent(key)}`);
      if (ws.ok) setWa(await ws.json());
    } catch (e2) {
      setKeyMsg(e2 instanceof Error ? `❌ ${e2.message}` : "❌ خطأ");
    } finally {
      setSavingKey(false);
    }
  };

  const resendNotify = async (o: Order) => {
    setNotifying(o.id);
    setNotifyMsg("");
    try {
      const res = await fetch(`/api/orders/notify?key=${encodeURIComponent(key)}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id: o.id }),
      });
      const data = await res.json();
      if (data.sent) {
        setNotifyMsg(`✅ تم إرسال الطلب #${o.id} لواتساب ديالك!`);
        setOrders((prev) => prev.map((x) => (x.id === o.id ? { ...x, whatsappSent: true } : x)));
      } else {
        // fallback: open wa.me link
        window.open(data.waLink || ownerWaLink(o), "_blank");
        setNotifyMsg(`⚠️ الإرسال الأوتوماتيكي غير مفعّل — حلينا ليك واتساب باش تصيفط يدوياً. فعّل CallMeBot (مجاني) ولا UltraMsg من قسم الواتساب! 👇`);
      }
    } catch {
      window.open(ownerWaLink(o), "_blank");
    } finally {
      setNotifying(null);
    }
  };

  const saveUltra = async (e: React.FormEvent) => {
    e.preventDefault();
    setSavingUltra(true);
    setUltraMsg("");
    try {
      const res = await fetch(`/api/whatsapp?key=${encodeURIComponent(key)}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ultramsg_instance: ultraInstance, ultramsg_token: ultraToken }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "خطأ");
      setUltraMsg("✅ تم الحفظ! دابا أي زبون كيطلب غتوصلو رسالة تأكيد أوتوماتيكية من الرقم ديالك 🎉📲");
      setUltraInstance("");
      setUltraToken("");
      const ws = await fetch(`/api/whatsapp?key=${encodeURIComponent(key)}`);
      if (ws.ok) setWa(await ws.json());
    } catch (e2) {
      setUltraMsg(e2 instanceof Error ? `❌ ${e2.message}` : "❌ خطأ");
    } finally {
      setSavingUltra(false);
    }
  };

  const resendCustomer = async (o: Order) => {
    setNotifyingCustomer(o.id);
    setNotifyMsg("");
    try {
      const res = await fetch(`/api/orders/notify?key=${encodeURIComponent(key)}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id: o.id, target: "customer" }),
      });
      const data = await res.json();
      if (data.sent) {
        setNotifyMsg(`✅ تم إرسال رسالة التأكيد للزبون ${o.fullName} من الرقم ديالك! 📲`);
        setOrders((prev) => prev.map((x) => (x.id === o.id ? { ...x, customerWhatsappSent: true } : x)));
      } else {
        window.open(data.waLink || customerWaLink(o), "_blank");
        setNotifyMsg(`⚠️ الإرسال الأوتوماتيكي للزبناء غير مفعّل — حلينا ليك واتساب باش تصيفط يدوياً. فعّل UltraMsg لتحت! 👇`);
      }
    } catch {
      window.open(customerWaLink(o), "_blank");
    } finally {
      setNotifyingCustomer(null);
    }
  };

  const filtered = filter === "all" ? orders : orders.filter((o) => o.status === filter);
  const autoOn = Boolean(wa && (wa.ownerReady || wa.meta || wa.callmebot || wa.ultramsg));
  const customerAutoOn = wa?.customerReady;

  if (!authed) {
    return (
      <div dir="rtl" className="grid min-h-screen place-items-center bg-slate-100 px-4">
        <form onSubmit={login} className="w-full max-w-sm rounded-3xl bg-white p-8 shadow-xl">
          <p className="text-center text-4xl">🔐</p>
          <h1 className="mt-2 text-center text-xl font-black">لوحة تحكم الطلبات</h1>
          <input
            type="password"
            value={key}
            onChange={(e) => setKey(e.target.value)}
            placeholder="كلمة السر"
            className="mt-4 w-full rounded-xl border-2 border-slate-200 px-4 py-3 font-bold outline-none focus:border-orange-500"
          />
          {error && <p className="mt-2 text-center text-sm font-bold text-red-600">{error}</p>}
          <button className="mt-3 w-full rounded-xl bg-slate-900 py-3 font-black text-white">
            {loading ? "جاري الدخول..." : "دخول"}
          </button>
        </form>
      </div>
    );
  }

  return (
    <div dir="rtl" className="min-h-screen bg-slate-100 p-4 md:p-8">
      <div className="mx-auto max-w-6xl">
        <div className="flex items-center justify-between">
          <h1 className="text-2xl font-black">📦 لوحة الطلبات — BaytiPro</h1>
          <div className="flex gap-2">
            <a
              href="/links"
              target="_blank"
              rel="noopener noreferrer"
              className="rounded-xl bg-slate-900 px-4 py-2 text-sm font-black text-white shadow"
            >
              🔗 روابطي
            </a>
            <button
              onClick={() => load(key)}
              className="rounded-xl bg-white px-4 py-2 text-sm font-black shadow"
            >
              🔄 تحديث
            </button>
          </div>
        </div>

        {/* WhatsApp status */}
        <div className={`mt-4 rounded-2xl border-2 p-4 ${autoOn ? "border-green-300 bg-green-50" : "border-amber-300 bg-amber-50"}`}>
          <div className="flex flex-wrap items-center gap-2">
            <span className="text-2xl">💬</span>
            <div>
              <p className="font-black">
                إشعارات الواتساب: {autoOn ? "✅ مفعّلة" : "⚠️ غير مفعّلة (يدوي فقط)"}
              </p>
              <p className="text-xs font-bold text-slate-500">
                الرقم: <span dir="ltr" className="font-black">0651840540</span>
                {wa?.callmebot && " • CallMeBot ✅"}
                {wa?.meta && " • Meta API ✅"}
                {wa?.ultramsg && " • UltraMsg ✅"}
              </p>
              <p className="mt-1 text-xs font-black">
                📲 رسالة الزبون الأوتوماتيكية:{" "}
                {customerAutoOn ? (
                  <span className="text-green-600">✅ مفعّلة — الزبون كيتوصل من الرقم ديالك</span>
                ) : (
                  <span className="text-amber-600">⚠️ غير مفعّلة — فعّلها لتحت 👇</span>
                )}
              </p>
            </div>
          </div>

          {!wa?.callmebot ? (
            <div className="mt-3 rounded-xl bg-white p-4 text-sm">
              <p className="font-black text-slate-800">🚀 باش توصلك الطلبات أوتوماتيكياً فواتساب (مجاني — 2 دقائق):</p>
              <ol className="mt-2 space-y-2 font-semibold leading-relaxed text-slate-600">
                <li>
                  1️⃣ سجّل هاد الرقم فالتيليفون ديالك (سميه CallMeBot):
                  <span className="mt-1 flex items-center justify-between gap-2 rounded-lg bg-slate-100 p-2">
                    <b dir="ltr" className="font-mono text-sm">{CALLMEBOT_NUM}</b>
                    <button
                      type="button"
                      onClick={() => copyTxt(CALLMEBOT_NUM, "cbnum")}
                      className="shrink-0 rounded-lg bg-white px-3 py-1 text-xs font-black text-slate-700 shadow-sm ring-1 ring-slate-200"
                    >
                      {copiedTxt === "cbnum" ? "✅" : "📋 نسخ"}
                    </button>
                  </span>
                </li>
                <li>
                  2️⃣ صيفط ليه <b>هاد الرسالة بالضبط</b> (كوبيها ولصقها بلا ما تزيد ولا تنقص حرف):
                  <span className="mt-1 flex items-center justify-between gap-2 rounded-lg bg-slate-100 p-2">
                    <span className="font-mono text-xs" dir="ltr">{CALLMEBOT_TEXT}</span>
                    <button
                      type="button"
                      onClick={() => copyTxt(CALLMEBOT_TEXT, "cbtext")}
                      className="shrink-0 rounded-lg bg-white px-3 py-1 text-xs font-black text-slate-700 shadow-sm ring-1 ring-slate-200"
                    >
                      {copiedTxt === "cbtext" ? "✅" : "📋 نسخ"}
                    </button>
                  </span>
                  <a
                    href={CALLMEBOT_LINK}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="mt-2 flex items-center justify-center gap-2 rounded-xl bg-[#25D366] px-4 py-2.5 font-black text-white"
                  >
                    💬 ولا ضغط هنا باش تحل المحادثة مباشرة (الرسالة واجدة)
                  </a>
                </li>
                <li>3️⃣ تسنى <b>حتى 2 دقائق</b> — غادي يرجع ليك رسالة فيها <b>APIKEY</b> (أرقام) خاص بيك — كوبيها.</li>
                <li>4️⃣ لصقها هنا لتحت وضغط حفظ — صافي! ✅</li>
              </ol>
              <form onSubmit={saveApikey} className="mt-3 flex gap-2">
                <input
                  value={apikey}
                  onChange={(e) => setApikey(e.target.value)}
                  placeholder="لصق الـ apikey هنا..."
                  dir="ltr"
                  className="flex-1 rounded-xl border-2 border-slate-200 px-4 py-2.5 text-left font-mono text-sm font-bold outline-none focus:border-green-500"
                />
                <button
                  disabled={savingKey}
                  className="shrink-0 rounded-xl bg-[#25D366] px-5 py-2.5 font-black text-white disabled:opacity-60"
                >
                  {savingKey ? "..." : "💾 حفظ"}
                </button>
              </form>
              {keyMsg && <p className="mt-2 text-sm font-black">{keyMsg}</p>}

              <details className="mt-3 rounded-xl bg-red-50 p-3 text-xs font-bold leading-relaxed text-red-800 ring-1 ring-red-200">
                <summary className="cursor-pointer font-black">🆘 الـ apikey ما وصلاتكش؟ جرّب هاد الحلول</summary>
                <ul className="mt-2 list-disc space-y-1.5 pr-4">
                  <li>تأكد أنك صيفطتي للرقم الجديد <b dir="ltr">{CALLMEBOT_NUM}</b> (الرقم القديم ما بقاش خدام!).</li>
                  <li>الرسالة خاصها تكون <b>حرف بحرف</b> كيف ما مكتوبة فوق — بلا زيادة بلا نقصان.</li>
                  <li>صيفط الرسالة <b>من نفس الرقم</b> اللي بغيتي توصلك فيه التنبيهات (<b dir="ltr">0651840540</b>).</li>
                  <li>تسنى 2 دقائق كاملين — أحياناً كيتعطل شوية.</li>
                  <li>إلا ما وصل والو: <b>عاود صيفط الرسالة من بعد 24 ساعة</b> (هادا هو الحل الرسمي من CallMeBot).</li>
                  <li>💡 <b>البديل السريع:</b> فعّل UltraMsg لتحت (قسم رسالة الزبون) — ملي يتفعل، حتى تنبيهات الطلبات غادي توصلك بيه بلا ما تحتاج CallMeBot!</li>
                </ul>
              </details>
              <p className="mt-2 text-[11px] font-bold text-slate-400">
                💡 ملاحظة: بلا هاد التفعيل، الزبون ملي كيطلب كيبان ليه زر &quot;أكّد طلبك عبر واتساب&quot; وكيصيفط ليك الطلب يدوياً — يعني الطلبات ما غاديش يضيعو.
              </p>
            </div>
          ) : (
            <details className="mt-2 text-xs font-bold text-slate-500">
              <summary className="cursor-pointer">بدّل الـ apikey</summary>
              <form onSubmit={saveApikey} className="mt-2 flex gap-2">
                <input
                  value={apikey}
                  onChange={(e) => setApikey(e.target.value)}
                  placeholder="apikey جديد..."
                  dir="ltr"
                  className="flex-1 rounded-xl border-2 border-slate-200 px-4 py-2 text-left font-mono text-sm outline-none focus:border-green-500"
                />
                <button disabled={savingKey} className="rounded-xl bg-[#25D366] px-4 py-2 font-black text-white">
                  حفظ
                </button>
              </form>
              {keyMsg && <p className="mt-1">{keyMsg}</p>}
            </details>
          )}

          {/* Test button */}
          <div className="mt-3 rounded-xl bg-white p-3">
            <div className="flex flex-wrap items-center gap-2">
              <p className="text-sm font-black text-slate-700">🧪 جرّب واش التنبيهات خدامة:</p>
              <button
                onClick={sendTest}
                disabled={testing}
                className="mr-auto rounded-xl bg-slate-900 px-5 py-2 text-sm font-black text-white disabled:opacity-50"
              >
                {testing ? "⏳ جاري الإرسال..." : "📲 صيفط رسالة تجريبية لواتساب ديالي"}
              </button>
            </div>
            {testResults && (
              <div className="mt-2 space-y-1.5">
                {testResults.map((r) => (
                  <p
                    key={r.method}
                    className={`rounded-lg p-2.5 text-xs font-black ${r.sent ? "bg-green-50 text-green-700 ring-1 ring-green-200" : "bg-red-50 text-red-700 ring-1 ring-red-200"}`}
                  >
                    {r.label}: {r.detail}
                  </p>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Customer auto message setup */}
        <div className={`mt-4 rounded-2xl border-2 p-4 ${customerAutoOn ? "border-green-300 bg-green-50" : "border-blue-300 bg-blue-50"}`}>
          <div className="flex flex-wrap items-center gap-2">
            <span className="text-2xl">📲</span>
            <div>
              <p className="font-black">
                رسالة الزبون الأوتوماتيكية: {customerAutoOn ? "✅ مفعّلة" : "⚠️ غير مفعّلة"}
              </p>
              <p className="text-xs font-bold text-slate-500">
                ملي الزبون كيطلب، كيتوصل مباشرة برسالة تأكيد فواتساب من الرقم ديالك <span dir="ltr" className="font-black">0651840540</span>
              </p>
            </div>
          </div>

          {!customerAutoOn && (
            <div className="mt-3 rounded-xl bg-white p-4 text-sm">
              <p className="font-black text-slate-800">🚀 باش تفعّلها (UltraMsg — 5 دقائق):</p>
              <ol className="mt-2 space-y-1.5 font-semibold leading-relaxed text-slate-600">
                <li>1️⃣ سجل مجاناً فـ <b dir="ltr">ultramsg.com</b> وصايب حساب جديد.</li>
                <li>2️⃣ زيد <b>Instance</b> جديد وربطو مع الواتساب ديالك <b dir="ltr">0651840540</b> (كيعطيك QR code تسكانيه بالتيليفون).</li>
                <li>3️⃣ من بعد الربط، كوبي الـ <b dir="ltr">Instance ID</b> والـ <b dir="ltr">Token</b> من لوحة UltraMsg.</li>
                <li>4️⃣ لصقهم هنا لتحت وضغط حفظ — صافي! ✅</li>
              </ol>
              <form onSubmit={saveUltra} className="mt-3 space-y-2">
                <input
                  value={ultraInstance}
                  onChange={(e) => setUltraInstance(e.target.value)}
                  placeholder="Instance ID (مثال: instance12345)"
                  dir="ltr"
                  className="w-full rounded-xl border-2 border-slate-200 px-4 py-2.5 text-left font-mono text-sm font-bold outline-none focus:border-green-500"
                />
                <div className="flex gap-2">
                  <input
                    value={ultraToken}
                    onChange={(e) => setUltraToken(e.target.value)}
                    placeholder="Token"
                    dir="ltr"
                    className="flex-1 rounded-xl border-2 border-slate-200 px-4 py-2.5 text-left font-mono text-sm font-bold outline-none focus:border-green-500"
                  />
                  <button
                    disabled={savingUltra}
                    className="shrink-0 rounded-xl bg-[#25D366] px-5 py-2.5 font-black text-white disabled:opacity-60"
                  >
                    {savingUltra ? "..." : "💾 حفظ"}
                  </button>
                </div>
              </form>
              {ultraMsg && <p className="mt-2 text-sm font-black">{ultraMsg}</p>}
              <div className="mt-3 rounded-xl bg-slate-50 p-3 text-xs font-bold leading-relaxed text-slate-600">
                <p className="font-black text-slate-800">💬 شنو غيتوصل بيها الزبون؟</p>
                <p className="mt-1">رسالة تأكيد بالدارجة: الشكر + رقم الطلب + الكمية + المبلغ + المراحل الجاية (تأكيد هاتفي ثم التوصيل لباب الدار) — من الرقم ديالك مباشرة.</p>
              </div>
              <p className="mt-2 text-[11px] font-bold text-slate-400">
                💡 بلا هاد التفعيل، تقدر تصيفط التأكيد يدوياً بزر &quot;💬 واتساب الزبون&quot; فكل طلب.
              </p>
              <p className="mt-1 text-[11px] font-bold text-slate-400">
                ⚠️ UltraMsg فيه فترة تجريبية مجانية، ومن بعد كيولي باشتراك شهري (~$39/شهر). جرّبو مجاناً وشوف واش يستاهل — وفجميع الحالات الطلبات والرسائل اليدوية خدامين بلا خلاص.
              </p>
            </div>
          )}
          {customerAutoOn && (
            <details className="mt-2 text-xs font-bold text-slate-500">
              <summary className="cursor-pointer">بدّل مفاتيح UltraMsg</summary>
              <form onSubmit={saveUltra} className="mt-2 space-y-2">
                <input
                  value={ultraInstance}
                  onChange={(e) => setUltraInstance(e.target.value)}
                  placeholder="Instance ID جديد..."
                  dir="ltr"
                  className="w-full rounded-xl border-2 border-slate-200 px-4 py-2 text-left font-mono text-sm outline-none focus:border-green-500"
                />
                <div className="flex gap-2">
                  <input
                    value={ultraToken}
                    onChange={(e) => setUltraToken(e.target.value)}
                    placeholder="Token جديد..."
                    dir="ltr"
                    className="flex-1 rounded-xl border-2 border-slate-200 px-4 py-2 text-left font-mono text-sm outline-none focus:border-green-500"
                  />
                  <button disabled={savingUltra} className="rounded-xl bg-[#25D366] px-4 py-2 font-black text-white">
                    حفظ
                  </button>
                </div>
              </form>
              {ultraMsg && <p className="mt-1">{ultraMsg}</p>}
            </details>
          )}
        </div>

        <div className="mt-4 grid grid-cols-3 gap-3">
          <div className="rounded-2xl bg-white p-4 text-center shadow">
            <p className="text-2xl font-black">{stats.total}</p>
            <p className="text-xs font-bold text-slate-500">مجموع الطلبات</p>
          </div>
          <div className="rounded-2xl bg-white p-4 text-center shadow">
            <p className="text-2xl font-black text-amber-600">{stats.pending}</p>
            <p className="text-xs font-bold text-slate-500">بانتظار التأكيد</p>
          </div>
          <div className="rounded-2xl bg-white p-4 text-center shadow">
            <p className="text-2xl font-black text-green-600">{stats.revenue.toLocaleString()} <span className="text-sm">درهم</span></p>
            <p className="text-xs font-bold text-slate-500">المداخيل المتوقعة</p>
          </div>
        </div>

        {notifyMsg && (
          <div className="mt-3 rounded-xl border border-blue-200 bg-blue-50 p-3 text-center text-sm font-black text-blue-800">
            {notifyMsg}
          </div>
        )}

        <div className="mt-4 flex gap-2 overflow-x-auto pb-1">
          {["all", "pending", "confirmed", "shipped", "delivered", "cancelled"].map((s) => (
            <button
              key={s}
              onClick={() => setFilter(s)}
              className={`shrink-0 rounded-full px-4 py-2 text-sm font-black ${
                filter === s ? "bg-slate-900 text-white" : "bg-white text-slate-600 shadow"
              }`}
            >
              {s === "all" ? "الكل" : STATUS_LABELS[s].label}
            </button>
          ))}
        </div>

        <div className="mt-4 space-y-3">
          {filtered.map((o) => (
            <div key={o.id} className="rounded-2xl bg-white p-4 shadow">
              <div className="flex flex-wrap items-center gap-2">
                <span className="font-black">#{o.id} — {o.fullName}</span>
                <span className={`rounded-full px-3 py-0.5 text-xs font-black ${STATUS_LABELS[o.status]?.color ?? "bg-slate-100"}`}>
                  {STATUS_LABELS[o.status]?.label ?? o.status}
                </span>
                {o.whatsappSent ? (
                  <span className="rounded-full bg-green-100 px-3 py-0.5 text-xs font-black text-green-700">💬 توصل واتساب ✅</span>
                ) : (
                  <span className="rounded-full bg-slate-100 px-3 py-0.5 text-xs font-black text-slate-500">💬 واتساب: لا</span>
                )}
                {o.customerWhatsappSent ? (
                  <span className="rounded-full bg-blue-100 px-3 py-0.5 text-xs font-black text-blue-700">📲 الزبون توصل ✅</span>
                ) : (
                  <span className="rounded-full bg-slate-100 px-3 py-0.5 text-xs font-black text-slate-500">📲 الزبون: لا</span>
                )}
                <span className="mr-auto text-xs font-bold text-slate-400">
                  {new Date(o.createdAt).toLocaleString("fr-MA")}
                </span>
              </div>
              <div className="mt-2 grid gap-1 text-sm font-semibold text-slate-600 md:grid-cols-2">
                <p>📞 <a href={`tel:${o.phone}`} dir="ltr" className="font-black text-blue-600">{o.phone}</a></p>
                <p>📍 {o.city} — {o.address}</p>
                <p>🔢 الكمية: <b>{o.quantity}</b> • المجموع: <b className="text-orange-600">{o.totalPrice} درهم</b></p>
                {o.notes && <p>📝 {o.notes}</p>}
              </div>
              <div className="mt-3 flex flex-wrap gap-2">
                <a
                  href={customerWaLink(o)}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="rounded-lg bg-[#25D366] px-3 py-1.5 text-xs font-black text-white hover:bg-[#1fb857]"
                >
                  💬 واتساب الزبون
                </a>
                <button
                  onClick={() => resendNotify(o)}
                  disabled={notifying === o.id}
                  className="rounded-lg bg-slate-900 px-3 py-1.5 text-xs font-black text-white disabled:opacity-50"
                >
                  {notifying === o.id ? "⏳..." : "📲 صيفط لواتساب ديالي"}
                </button>
                <button
                  onClick={() => resendCustomer(o)}
                  disabled={notifyingCustomer === o.id}
                  className="rounded-lg bg-blue-600 px-3 py-1.5 text-xs font-black text-white hover:bg-blue-500 disabled:opacity-50"
                >
                  {notifyingCustomer === o.id ? "⏳..." : "📲 صيفط تأكيد للزبون"}
                </button>
              </div>
              <div className="mt-2 flex flex-wrap gap-2 border-t border-slate-100 pt-2">
                {Object.keys(STATUS_LABELS).map((s) => (
                  <button
                    key={s}
                    onClick={() => updateStatus(o.id, s)}
                    className={`rounded-lg px-3 py-1.5 text-xs font-black ${
                      o.status === s ? "bg-slate-900 text-white" : "bg-slate-100 text-slate-600 hover:bg-slate-200"
                    }`}
                  >
                    {STATUS_LABELS[s].label}
                  </button>
                ))}
              </div>
            </div>
          ))}
          {filtered.length === 0 && (
            <p className="rounded-2xl bg-white p-8 text-center font-bold text-slate-400">
              {loading ? "جاري التحميل..." : "لا توجد طلبات"}
            </p>
          )}
        </div>

        <SourceFiles adminKey={key} />
      </div>
    </div>
  );
}
