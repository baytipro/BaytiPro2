import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

const siteUrl = (process.env.NEXT_PUBLIC_SITE_URL || "https://baytipro.vercel.app").replace(/\/$/, "");

export const metadata: Metadata = {
  metadataBase: new URL(siteUrl),
  title: "سخان الماء الغازي الفوري 6L | BaytiPro عرض الشتاء - 890 درهم فقط",
  description:
    "بمناسبة حلول فصل الشتاء: عرض قوي على سخان الماء الغازي الفوري 6L عالي الجودة، صنع في المغرب. ماء ساخن فوري، ضمان 6 أشهر، الدفع عند الاستلام والتوصيل لجميع المدن. الثمن 890 درهم فقط بدل 1299 درهم. BaytiPro — متجر رشيد.",
  keywords: ["سخان ماء غازي", "chauffe eau gaz", "BaytiPro", "بيتي برو", "سخان فوري", "المغرب", "عرض الشتاء"],
  alternates: { canonical: "/" },
  openGraph: {
    title: "عرض الشتاء 🔥 سخان الماء الغازي 6L بـ 890 درهم فقط | BaytiPro",
    description: "ماء ساخن فوري في ثواني! جودة عالية ⭐ • صنع في المغرب • ضمان 6 أشهر • الدفع عند الاستلام",
    type: "website",
    locale: "ar_MA",
    siteName: "BaytiPro — بيتي برو",
    url: "/",
  },
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="ar" dir="rtl">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;500;600;700;800;900&family=Tajawal:wght@400;500;700;800;900&display=swap"
          rel="stylesheet"
        />
      </head>
      <body className="bg-slate-50 text-slate-900 antialiased">{children}</body>
    </html>
  );
}
