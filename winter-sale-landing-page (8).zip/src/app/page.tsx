import Landing from "@/components/landing";
import { db } from "@/db";
import { orders } from "@/db/schema";
import { sql } from "drizzle-orm";

export const dynamic = "force-dynamic";

export default async function HomePage() {
  let ordersToday = 23;
  try {
    const res = await db
      .select({ c: sql<number>`count(*)::int` })
      .from(orders)
      .where(sql`${orders.createdAt}::date = CURRENT_DATE`);
    ordersToday = 23 + (res[0]?.c ?? 0);
  } catch {
    // table may not exist yet on first boot — fallback value
  }
  return <Landing ordersToday={ordersToday} />;
}
