export const BRAND = {
  name: "BaytiPro",
  ar: "بيتي برو",
  owner: "رشيد",
  tagline: "بيتي برو — متجر رشيد 🏠",
};

// Official public URL of the store — used for sharing & SEO.
// Priority: 1) NEXT_PUBLIC_SITE_URL env, 2) custom URL saved in admin, 3) current origin.
export const OFFICIAL_SITE_URL_ENV = (process.env.NEXT_PUBLIC_SITE_URL || "").replace(/\/$/, "");
// Suggested free domain when deploying on Vercel with project name "baytipro"
export const SUGGESTED_VERCEL_URL = "https://baytipro.vercel.app";

export function normalizeSiteUrl(raw: string): string {
  let u = (raw || "").trim().replace(/\/+$/, "");
  if (!u) return "";
  if (!/^https?:\/\//i.test(u)) u = "https://" + u;
  try {
    const parsed = new URL(u);
    if (parsed.protocol !== "http:" && parsed.protocol !== "https:") return "";
    const host = parsed.hostname;
    // Strict hostname check: labels of letters/digits/hyphens separated by dots, must contain a dot
    if (!/^(?=.{3,253}$)([a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,}$/i.test(host)) return "";
    return parsed.origin.toLowerCase();
  } catch {
    return "";
  }
}

export const OWNER_PHONE_DISPLAY = "06 51 84 05 40";
export const OWNER_PHONE_INTL = "212651840540";
export const OWNER_WHATSAPP_LINK = "https://wa.me/212651840540";

export const PRODUCT = {
  name: "سخان الغاز 6L",
  fullName: "سخان الماء الغازي الفوري 6L",
  tagline: "Chauffe-eau instantané à gaz — 6 Litres",
  price: 890,
  oldPrice: 1299,
  currency: "درهم",
  madeIn: "صنع في المغرب 🇲🇦",
  warranty: "6 أشهر",
  quality: "جودة عالية ممتازة ⭐",
  rating: 4.8,
  reviewsCount: 1247,
  soldCount: 3800,
  stockLeft: 17,
};

export const QUANTITY_OFFERS = [
  { qty: 1, price: 890, oldPrice: 1299, label: "جهاز واحد", badge: "الأكثر طلباً", save: "وفّر 409 درهم" },
  { qty: 2, price: 1680, oldPrice: 2598, label: "جهازين (دار + دار الوالدين)", badge: "عرض العائلة 🔥", save: "وفّر 918 درهم" },
  { qty: 3, price: 2350, oldPrice: 3897, label: "3 أجهزة (عمارة / مشروع)", badge: "أحسن ثمن 💰", save: "وفّر 1547 درهم" },
];

export const MOROCCAN_CITIES = [
  "الدار البيضاء", "الرباط", "مراكش", "فاس", "مكناس", "طنجة", "أكادير", "وجدة",
  "القنيطرة", "تطوان", "سلا", "المحمدية", "الجديدة", "بني ملال", "الناظور",
  "الحسيمة", "خريبكة", "برشيد", "سطات", "القصر الكبير", "العرائش", "آسفي",
  "الصويرة", "كلميم", "العيون", "الداخلة", "ورزازات", "الرشيدية", "أزيلال",
  "تازة", "الحاجب", "إفران", "أزرو", "خنيفرة", "سيدي قاسم", "سيدي سليمان",
  "الفقيه بن صالح", "قلعة السراغنة", "شيشاوة", "اليوسفية", "طانطان", "تزنيت",
  "سيدي إفني", "زاكورة", "تنغير", "ميدلت", "جرسيف", "بركان", "تاوريرت", "فكيك",
  "شفشاون", "وزان", "سيدي بنور", "بنسليمان", "مدينة أخرى",
];

export function isValidMoroccanPhone(phone: string): boolean {
  const cleaned = phone.replace(/[\s-]/g, "");
  return /^(?:\+212|0)(6|7)\d{8}$/.test(cleaned);
}

export function formatPrice(n: number): string {
  return n.toLocaleString("fr-MA").replace(/,/g, " ") + " درهم";
}
