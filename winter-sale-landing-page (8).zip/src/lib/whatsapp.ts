import { db } from "@/db";
import { settings } from "@/db/schema";
import { eq } from "drizzle-orm";

// Owner WhatsApp (international format without +)
export const OWNER_WHATSAPP_INTL = "212651840540";
export const OWNER_WHATSAPP_DISPLAY = "0651840540";

// Official CallMeBot activation bot (from callmebot.com docs)
export const CALLMEBOT_NUMBER_DISPLAY = "+34 684 770 005";
export const CALLMEBOT_NUMBER_INTL = "34684770005";
export const CALLMEBOT_ACTIVATION_TEXT = "I allow callmebot to send me messages";
export const CALLMEBOT_CHAT_LINK = `https://wa.me/${CALLMEBOT_NUMBER_INTL}?text=${encodeURIComponent(CALLMEBOT_ACTIVATION_TEXT)}`;

export type OrderInfo = {
  id: number;
  fullName: string;
  phone: string;
  city: string;
  address: string;
  quantity: number;
  totalPrice: number;
  createdAt?: string | Date;
};

/** Normalize Moroccan phone to international format (212...) */
export function toIntl(phone: string): string {
  const cleaned = phone.replace(/[\s-]/g, "");
  if (cleaned.startsWith("+212")) return cleaned.slice(1);
  if (cleaned.startsWith("212")) return cleaned;
  if (cleaned.startsWith("0")) return "212" + cleaned.slice(1);
  return cleaned;
}

/** The Arabic order message sent to the owner */
export function formatOwnerMessage(o: OrderInfo): string {
  const lines = [
    "🔥 *طلب جديد! — سخان الغاز 6L (BaytiPro)*",
    "━━━━━━━━━━━━━━",
    `🧾 رقم الطلب: *#${o.id}*`,
    `👤 الاسم: ${o.fullName}`,
    `📞 الهاتف: ${o.phone}`,
    `📍 المدينة: ${o.city}`,
    `🏠 العنوان: ${o.address}`,
    `🔢 الكمية: ${o.quantity} ${o.quantity === 1 ? "جهاز" : "أجهزة"}`,
    `💰 المجموع عند الاستلام: *${o.totalPrice} درهم*`,
    "━━━━━━━━━━━━━━",
    "📦 الدفع عند الاستلام — عيّط للزبون باش تأكد الطلب!",
  ];
  return lines.join("\n");
}

/** Automatic confirmation message sent TO the customer (from owner's number) */
export function formatCustomerMessage(o: OrderInfo): string {
  const lines = [
    `السلام عليكم ${o.fullName} 👋`,
    "",
    "شكراً على الثقة ديالك! توصلنا بالطلب ديالك بنجاح 🎉",
    "",
    "🧾 *تفاصيل الطلب:*",
    `▪️ رقم الطلب: *#${o.id}*`,
    `▪️ المنتوج: سخان الماء الغازي الفوري 6L ⭐`,
    `▪️ الكمية: ${o.quantity} ${o.quantity === 1 ? "جهاز" : "أجهزة"}`,
    `▪️ المجموع عند الاستلام: *${o.totalPrice} درهم* 💰`,
    `▪️ المدينة: ${o.city}`,
    "",
    "📦 *شنو من بعد؟*",
    "1️⃣ غادي نتصلو بيك قريباً باش نأكدو الطلب",
    "2️⃣ من بعد كنصيفطو ليك السلعة حتى لباب الدار 🚚",
    "3️⃣ كتخلص غير ملي توصلك وتشوفها بعينيك 💵",
    "",
    "🛡️ ضمان 6 أشهر + جودة مفحوصة ⭐",
    "",
    "عندك شي سؤال؟ جاوب على هاد الرسالة مباشرة 👇",
    "— *BaytiPro | متجر رشيد* 🏠",
  ];
  return lines.join("\n");
}

/** wa.me deep link that opens owner's chat with the order prefilled */
export function buildOwnerWaLink(o: OrderInfo): string {
  return `https://wa.me/${OWNER_WHATSAPP_INTL}?text=${encodeURIComponent(formatOwnerMessage(o))}`;
}

/** wa.me link to chat with the customer (manual fallback) */
export function buildCustomerWaLink(o: OrderInfo): string {
  return `https://wa.me/${toIntl(o.phone)}?text=${encodeURIComponent(formatCustomerMessage(o))}`;
}

export async function getSetting(key: string): Promise<string | null> {
  try {
    const rows = await db.select().from(settings).where(eq(settings.key, key)).limit(1);
    const v = rows[0]?.value?.trim();
    return v ? v : null;
  } catch {
    return null;
  }
}

async function getUltraMsgCreds(): Promise<{ instance: string; token: string } | null> {
  const instance = process.env.ULTRAMSG_INSTANCE_ID?.trim() || (await getSetting("ultramsg_instance"));
  const token = process.env.ULTRAMSG_TOKEN?.trim() || (await getSetting("ultramsg_token"));
  if (instance && token) return { instance, token };
  return null;
}

/** Send via CallMeBot free WhatsApp API (owner only) */
async function sendViaCallMeBot(text: string): Promise<{ ok: boolean; error?: string }> {
  const apiKey =
    process.env.CALLMEBOT_APIKEY?.trim() || (await getSetting("callmebot_apikey"));
  if (!apiKey) return { ok: false, error: "no-callmebot-key" };
  const url = `https://api.callmebot.com/whatsapp.php?phone=${OWNER_WHATSAPP_INTL}&text=${encodeURIComponent(text)}&apikey=${encodeURIComponent(apiKey)}`;
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), 15000);
  try {
    const res = await fetch(url, { signal: ctrl.signal });
    const body = await res.text();
    if (res.ok) return { ok: true };
    return { ok: false, error: `callmebot-${res.status}: ${body.slice(0, 200)}` };
  } catch (e) {
    return { ok: false, error: e instanceof Error ? e.message : "network-error" };
  } finally {
    clearTimeout(t);
  }
}

/** Send via Meta WhatsApp Cloud API to any number (if configured) */
async function sendViaMetaCloud(
  to: string,
  text: string
): Promise<{ ok: boolean; error?: string }> {
  const token = process.env.WHATSAPP_TOKEN?.trim();
  const phoneId = process.env.WHATSAPP_PHONE_NUMBER_ID?.trim();
  if (!token || !phoneId) return { ok: false, error: "no-meta-config" };
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), 15000);
  try {
    const res = await fetch(`https://graph.facebook.com/v21.0/${phoneId}/messages`, {
      method: "POST",
      headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        messaging_product: "whatsapp",
        to,
        type: "text",
        text: { body: text },
      }),
      signal: ctrl.signal,
    });
    if (res.ok) return { ok: true };
    const body = await res.text();
    return { ok: false, error: `meta-${res.status}: ${body.slice(0, 200)}` };
  } catch (e) {
    return { ok: false, error: e instanceof Error ? e.message : "network-error" };
  } finally {
    clearTimeout(t);
  }
}

/**
 * Send via UltraMsg — sends FROM the owner's own WhatsApp number
 * to any customer number. Ideal for automatic customer confirmations.
 * Docs: https://docs.ultramsg.com
 */
async function sendViaUltraMsg(
  to: string,
  text: string
): Promise<{ ok: boolean; error?: string }> {
  const creds = await getUltraMsgCreds();
  if (!creds) return { ok: false, error: "no-ultramsg-config" };
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), 20000);
  try {
    const params = new URLSearchParams();
    params.append("token", creds.token);
    params.append("to", to);
    params.append("body", text);
    const res = await fetch(`https://api.ultramsg.com/${encodeURIComponent(creds.instance)}/messages/chat`, {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: params.toString(),
      signal: ctrl.signal,
    });
    const body = await res.text();
    if (res.ok) {
      // UltraMsg returns { sent: "true", ... } on success
      try {
        const json = JSON.parse(body) as { sent?: string; error?: unknown };
        if (json.sent === "true") return { ok: true };
        return { ok: false, error: `ultramsg-rejected: ${body.slice(0, 200)}` };
      } catch {
        return { ok: true };
      }
    }
    return { ok: false, error: `ultramsg-${res.status}: ${body.slice(0, 200)}` };
  } catch (e) {
    return { ok: false, error: e instanceof Error ? e.message : "network-error" };
  } finally {
    clearTimeout(t);
  }
}

export type NotifyResult = {
  sent: boolean;
  method: "callmebot" | "meta" | "ultramsg" | "none";
  error?: string;
  waLink: string;
};

/** Try to notify the owner on WhatsApp about a new order. Never throws. */
export async function notifyOwnerOnWhatsApp(order: OrderInfo): Promise<NotifyResult> {
  const text = formatOwnerMessage(order);
  const waLink = buildOwnerWaLink(order);

  // 1) Meta Cloud API preferred if configured
  if (process.env.WHATSAPP_TOKEN && process.env.WHATSAPP_PHONE_NUMBER_ID) {
    const r = await sendViaMetaCloud(OWNER_WHATSAPP_INTL, text);
    if (r.ok) return { sent: true, method: "meta", waLink };
    console.error("Meta WhatsApp send failed:", r.error);
  }

  // 2) CallMeBot (free)
  const cb = await sendViaCallMeBot(text);
  if (cb.ok) return { sent: true, method: "callmebot", waLink };
  if (cb.error && cb.error !== "no-callmebot-key") {
    console.error("CallMeBot send failed:", cb.error);
  }

  // 3) UltraMsg fallback — sends to the owner number itself
  // (works when UltraMsg is already set up for customer messages)
  const ultra = await sendViaUltraMsg(OWNER_WHATSAPP_INTL, text);
  if (ultra.ok) return { sent: true, method: "ultramsg", waLink };
  if (ultra.error && ultra.error !== "no-ultramsg-config") {
    console.error("UltraMsg owner send failed:", ultra.error);
  }

  return { sent: false, method: "none", error: cb.error, waLink };
}

/** Send a test message to the owner via every configured method. Never throws. */
export async function sendOwnerTestMessage(): Promise<{
  results: { method: string; label: string; sent: boolean; detail: string }[];
}> {
  const text = "✅ هادي رسالة تجريبية من متجر BaytiPro — إلا وصلاتك يعني التنبيهات الأوتوماتيكية خدامة! 🎉";
  const results: { method: string; label: string; sent: boolean; detail: string }[] = [];

  const metaConfigured = Boolean(process.env.WHATSAPP_TOKEN && process.env.WHATSAPP_PHONE_NUMBER_ID);
  const cbConfigured = Boolean(process.env.CALLMEBOT_APIKEY?.trim() || (await getSetting("callmebot_apikey")));
  const ultraConfigured = Boolean(await getUltraMsgCreds());

  if (!metaConfigured && !cbConfigured && !ultraConfigured) {
    results.push({
      method: "none",
      label: "لا توجد طريقة مفعّلة",
      sent: false,
      detail: "ما كاين حتى مفتاح محفوظ. فعّل CallMeBot (مجاني) ولا UltraMsg لتحت.",
    });
    return { results };
  }

  if (metaConfigured) {
    const r = await sendViaMetaCloud(OWNER_WHATSAPP_INTL, text);
    results.push({
      method: "meta",
      label: "Meta Cloud API",
      sent: r.ok,
      detail: r.ok ? "✅ وصلات! شوف واتساب ديالك" : `❌ فشلات: ${r.error}`,
    });
  }

  if (cbConfigured) {
    const r = await sendViaCallMeBot(text);
    results.push({
      method: "callmebot",
      label: "CallMeBot (مجاني)",
      sent: r.ok,
      detail: r.ok
        ? "✅ وصلات! شوف واتساب ديالك"
        : `❌ فشلات: ${r.error} — تأكد أن الـ apikey صحيحة وبعتي رسالة التفعيل من نفس الرقم`,
    });
  }

  if (ultraConfigured) {
    const r = await sendViaUltraMsg(OWNER_WHATSAPP_INTL, text);
    results.push({
      method: "ultramsg",
      label: "UltraMsg",
      sent: r.ok,
      detail: r.ok ? "✅ وصلات! شوف واتساب ديالك" : `❌ فشلات: ${r.error}`,
    });
  }

  return { results };
}

/**
 * Try to send the customer an automatic confirmation FROM the owner's
 * WhatsApp number. Requires UltraMsg (recommended) or Meta Cloud API.
 * Never throws.
 */
export async function notifyCustomerOnWhatsApp(order: OrderInfo): Promise<NotifyResult> {
  const text = formatCustomerMessage(order);
  const waLink = buildCustomerWaLink(order);
  const to = toIntl(order.phone);

  // 1) UltraMsg — sends from owner's own number (recommended)
  const ultra = await sendViaUltraMsg(to, text);
  if (ultra.ok) return { sent: true, method: "ultramsg", waLink };
  if (ultra.error && ultra.error !== "no-ultramsg-config") {
    console.error("UltraMsg customer send failed:", ultra.error);
  }

  // 2) Meta Cloud API fallback
  if (process.env.WHATSAPP_TOKEN && process.env.WHATSAPP_PHONE_NUMBER_ID) {
    const r = await sendViaMetaCloud(to, text);
    if (r.ok) return { sent: true, method: "meta", waLink };
    console.error("Meta customer send failed:", r.error);
    return { sent: false, method: "none", error: r.error, waLink };
  }

  return { sent: false, method: "none", error: ultra.error, waLink };
}

/** Check which auto-send methods are configured */
export async function getWhatsAppStatus(): Promise<{
  meta: boolean;
  callmebot: boolean;
  ultramsg: boolean;
  customerReady: boolean;
  ownerReady: boolean;
  owner: string;
}> {
  const dbKey = await getSetting("callmebot_apikey");
  const ultra = await getUltraMsgCreds();
  const meta = Boolean(process.env.WHATSAPP_TOKEN && process.env.WHATSAPP_PHONE_NUMBER_ID);
  const ultramsg = Boolean(ultra);
  const callmebot = Boolean(process.env.CALLMEBOT_APIKEY?.trim() || dbKey);
  return {
    meta,
    callmebot,
    ultramsg,
    customerReady: ultramsg || meta,
    ownerReady: meta || callmebot || ultramsg,
    owner: OWNER_WHATSAPP_DISPLAY,
  };
}
