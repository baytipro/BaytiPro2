"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import {
  PRODUCT,
  QUANTITY_OFFERS,
  MOROCCAN_CITIES,
  isValidMoroccanPhone,
  formatPrice,
  OWNER_PHONE_DISPLAY,
  OWNER_PHONE_INTL,
  OWNER_WHATSAPP_LINK,
} from "@/lib/store";

/* ---------------- Snowfall ---------------- */
function Snowfall({ count = 26 }: { count?: number }) {
  const flakes = useMemo(
    () =>
      Array.from({ length: count }, (_, i) => ({
        id: i,
        left: Math.random() * 100,
        size: 8 + Math.random() * 18,
        duration: 7 + Math.random() * 10,
        delay: Math.random() * 10,
        char: ["❄", "❅", "❆", "•"][Math.floor(Math.random() * 4)],
      })),
    [count]
  );
  return (
    <div className="pointer-events-none absolute inset-0 overflow-hidden" aria-hidden>
      {flakes.map((f) => (
        <span
          key={f.id}
          className="snowflake"
          style={{
            left: `${f.left}%`,
            fontSize: f.size,
            animationDuration: `${f.duration}s`,
            animationDelay: `${f.delay}s`,
          }}
        >
          {f.char}
        </span>
      ))}
    </div>
  );
}

/* ---------------- Countdown ---------------- */
function useCountdown() {
  const [left, setLeft] = useState({ h: 0, m: 0, s: 0 });
  useEffect(() => {
    const tick = () => {
      const now = new Date();
      const end = new Date(now);
      end.setHours(23, 59, 59, 999);
      const diff = Math.max(0, end.getTime() - now.getTime());
      setLeft({
        h: Math.floor(diff / 3600000),
        m: Math.floor((diff % 3600000) / 60000),
        s: Math.floor((diff % 60000) / 1000),
      });
    };
    tick();
    const id = setInterval(tick, 1000);
    return () => clearInterval(id);
  }, []);
  return left;
}

function CountdownBox({ dark = false }: { dark?: boolean }) {
  const { h, m, s } = useCountdown();
  const pad = (n: number) => String(n).padStart(2, "0");
  const cell = dark
    ? "bg-white/10 border-white/20 text-white"
    : "bg-navy-950 border-navy-800 text-white";
  return (
    <div className="flex items-center justify-center gap-2" dir="ltr">
      {[
        { v: pad(h), l: "ساعة" },
        { v: pad(m), l: "دقيقة" },
        { v: pad(s), l: "ثانية" },
      ].map((u, i) => (
        <div key={u.l} className="flex items-center gap-2">
          <div
            className={`flex min-w-[64px] flex-col items-center rounded-2xl border px-3 py-2 shadow-lg ${cell}`}
          >
            <span className="text-2xl font-black tabular-nums leading-none">{u.v}</span>
            <span className="mt-1 text-[11px] font-semibold opacity-80">{u.l}</span>
          </div>
          {i < 2 && <span className="text-2xl font-black text-orange-500">:</span>}
        </div>
      ))}
    </div>
  );
}

/* ---------------- Social proof toast ---------------- */
const FAKE_BUYERS = [
  { name: "ياسين من الدار البيضاء", detail: "طلب جهاز واحد — قبل 12 دقيقة", city: "الدار البيضاء" },
  { name: "فاطمة من مراكش", detail: "طلبت جهازين — قبل 25 دقيقة", city: "مراكش" },
  { name: "عبد الله من فاس", detail: "طلب جهاز واحد — قبل 40 دقيقة", city: "فاس" },
  { name: "خديجة من أكادير", detail: "طلبت جهاز واحد — قبل ساعة", city: "أكادير" },
  { name: "محمد من طنجة", detail: "طلب 3 أجهزة — قبل ساعة ونص", city: "طنجة" },
  { name: "سعاد من الرباط", detail: "طلبت جهاز واحد — قبل ساعتين", city: "الرباط" },
  { name: "رشيد من مكناس", detail: "طلب جهاز واحد — قبل 3 ساعات", city: "مكناس" },
  { name: "نادية من وجدة", detail: "طلبت جهازين — قبل 4 ساعات", city: "وجدة" },
];

function SocialToast() {
  const [idx, setIdx] = useState(0);
  const [show, setShow] = useState(false);
  useEffect(() => {
    let showT: ReturnType<typeof setTimeout>;
    let hideT: ReturnType<typeof setTimeout>;
    const loop = (i: number) => {
      showT = setTimeout(() => {
        setIdx(i % FAKE_BUYERS.length);
        setShow(true);
        hideT = setTimeout(() => {
          setShow(false);
          loop(i + 1);
        }, 4500);
      }, 9000);
    };
    loop(0);
    return () => {
      clearTimeout(showT);
      clearTimeout(hideT);
    };
  }, []);
  const b = FAKE_BUYERS[idx];
  return (
    <div
      className={`fixed bottom-24 right-3 z-40 flex max-w-[300px] items-center gap-3 rounded-2xl border border-white/10 bg-navy-950/95 p-3 text-white shadow-2xl backdrop-blur transition-all duration-500 md:bottom-6 md:right-6 ${
        show ? "translate-y-0 opacity-100" : "pointer-events-none translate-y-6 opacity-0"
      }`}
    >
      <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-green-500 text-xl font-black">
        ✓
      </div>
      <div>
        <p className="text-sm font-bold">🔥 {b.name}</p>
        <p className="text-xs text-white/70">{b.detail}</p>
      </div>
    </div>
  );
}

/* ---------------- Order form ---------------- */
function OrderForm({ initialQty = 1 }: { initialQty?: number }) {
  const [qty, setQty] = useState(initialQty);
  const [form, setForm] = useState({ fullName: "", phone: "", city: "", address: "", notes: "" });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState<{
    id: number;
    total: number;
    qty: number;
    waLink: string;
    whatsappSent: boolean;
    customerWhatsappSent: boolean;
  } | null>(null);

  // allow hero buttons to change qty
  useEffect(() => {
    const handler = (e: Event) => {
      const q = (e as CustomEvent<number>).detail;
      if (q >= 1 && q <= 3) setQty(q);
      document.getElementById("order")?.scrollIntoView({ behavior: "smooth" });
    };
    window.addEventListener("select-qty", handler);
    return () => window.removeEventListener("select-qty", handler);
  }, []);

  const offer = QUANTITY_OFFERS.find((o) => o.qty === qty) ?? QUANTITY_OFFERS[0];

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    if (form.fullName.trim().length < 3) return setError("المرجو إدخال الاسم الكامل");
    if (!isValidMoroccanPhone(form.phone)) return setError("المرجو إدخال رقم هاتف صحيح (06XXXXXXXX أو 07XXXXXXXX)");
    if (!form.city) return setError("المرجو اختيار المدينة");
    if (form.address.trim().length < 5) return setError("المرجو إدخال العنوان الكامل (الحي، الزنقة...)");
    setLoading(true);
    try {
      const res = await fetch("/api/orders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...form, quantity: qty }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "خطأ");
      // fallback wa.me link built on client in case server didn't return one
      const fallbackMsg = `🔥 طلب جديد! — سخان الغاز 6L (BaytiPro)\n🧾 رقم الطلب: #${data.order.id}\n👤 الاسم: ${form.fullName.trim()}\n📞 الهاتف: ${form.phone.trim()}\n📍 المدينة: ${form.city}\n🏠 العنوان: ${form.address.trim()}\n🔢 الكمية: ${qty}\n💰 المجموع: ${data.order.totalPrice} درهم`;
      const waLink =
        data.waLink ||
        `https://wa.me/${OWNER_PHONE_INTL}?text=${encodeURIComponent(fallbackMsg)}`;
      setSuccess({
        id: data.order.id,
        total: data.order.totalPrice,
        qty,
        waLink,
        whatsappSent: Boolean(data.whatsappSent),
        customerWhatsappSent: Boolean(data.customerWhatsappSent),
      });
      window.scrollTo({ top: document.getElementById("order")?.offsetTop ?? 0, behavior: "smooth" });
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : "حدث خطأ، عاود المحاولة");
    } finally {
      setLoading(false);
    }
  };

  if (success) {
    return (
      <div className="rounded-3xl border-2 border-green-500 bg-green-50 p-8 text-center">
        <div className="mx-auto flex h-20 w-20 items-center justify-center rounded-full bg-green-500 text-4xl text-white shadow-lg">
          ✓
        </div>
        <h3 className="mt-4 text-2xl font-black text-green-800">شكراً! تم استلام طلبك بنجاح 🎉</h3>
        <p className="mt-2 font-semibold text-green-700">
          رقم الطلب: <span className="font-black">#{success.id}</span>
        </p>
        <div className="mx-auto mt-4 max-w-sm rounded-2xl bg-white p-4 shadow">
          <p className="text-sm text-slate-600">المبلغ الإجمالي عند الاستلام:</p>
          <p className="text-3xl font-black text-orange-600">{formatPrice(success.total)}</p>
          <p className="mt-1 text-xs font-bold text-green-600">✓ الدفع عند الاستلام • التوصيل مجاني 🚚</p>
        </div>
        {success.customerWhatsappSent && (
          <div className="mx-auto mt-4 max-w-sm rounded-2xl border-2 border-green-500 bg-white p-3 text-sm font-black text-green-700 shadow">
            📲 صيفطنا ليك رسالة تأكيد فواتساب من الرقم ديالنا — شوف تيليفونك ✅
          </div>
        )}
        {success.whatsappSent ? (
          <div className="mx-auto mt-4 max-w-sm rounded-2xl border-2 border-green-300 bg-white p-3 text-sm font-black text-green-700">
            ✅ توصلنا بطلبك وغادي نتصلو بيك قريباً باش نأكدوه!
          </div>
        ) : (
          <div className="mx-auto mt-4 max-w-sm rounded-2xl border-2 border-green-500 bg-white p-4 shadow-lg">
            <p className="text-sm font-black text-slate-800">
              ⚡ خطوة أخيرة باش نوصلو طلبك بسرعة البرق:
            </p>
            <a
              href={success.waLink}
              target="_blank"
              rel="noopener noreferrer"
              className="mt-3 flex items-center justify-center gap-2 rounded-2xl bg-[#25D366] px-6 py-3.5 text-lg font-black text-white shadow-xl transition hover:scale-[1.02] hover:bg-[#1fb857]"
            >
              <svg viewBox="0 0 24 24" className="h-6 w-6 fill-current" aria-hidden>
                <path d="M17.5 14.4c-.3-.15-1.76-.87-2.03-.97-.27-.1-.47-.15-.67.15-.2.3-.77.97-.94 1.17-.17.2-.35.22-.65.07-.3-.15-1.26-.46-2.4-1.48-.88-.79-1.48-1.76-1.65-2.06-.17-.3-.02-.46.13-.61.14-.13.3-.35.45-.52.15-.17.2-.3.3-.5.1-.2.05-.37-.02-.52-.08-.15-.67-1.62-.92-2.22-.24-.58-.49-.5-.67-.51h-.57c-.2 0-.52.07-.8.37-.27.3-1.04 1.02-1.04 2.5 0 1.47 1.07 2.9 1.22 3.1.15.2 2.1 3.2 5.1 4.49.71.31 1.27.49 1.7.63.72.23 1.37.2 1.88.12.58-.09 1.76-.72 2-1.42.25-.7.25-1.29.18-1.42-.08-.13-.28-.2-.58-.35M12.05 21.79h-.01a9.87 9.87 0 0 1-5.03-1.38l-.36-.21-3.74.98 1-3.65-.24-.37a9.85 9.85 0 1 1 8.38 4.63m8.42-18.29A11.82 11.82 0 0 0 12.04 0C5.5 0 .16 5.34.16 11.9c0 2.1.55 4.14 1.59 5.95L.06 24l6.3-1.65a11.9 11.9 0 0 0 5.68 1.45h.01c6.55 0 11.89-5.34 11.89-11.9 0-3.18-1.24-6.16-3.47-8.4" />
              </svg>
              أكّد طلبك عبر واتساب
            </a>
            <p className="mt-2 text-[11px] font-bold text-slate-500">
              ضغط على الزر غادي تحل واتساب فيها تفاصيل طلبك واجدة — غير صيفطها لينا ✅
            </p>
          </div>
        )}
        <p className="mt-4 text-sm font-semibold text-slate-600">
          📞 غادي نتصلو بيك قريباً باش نأكدو الطلب. خلي تيليفونك خدام!
        </p>
      </div>
    );
  }

  return (
    <form onSubmit={submit} className="space-y-4">
      {/* qty selector */}
      <div className="grid gap-3">
        {QUANTITY_OFFERS.map((o) => (
          <button
            key={o.qty}
            type="button"
            onClick={() => setQty(o.qty)}
            className={`relative flex items-center justify-between rounded-2xl border-2 p-4 text-right transition-all ${
              qty === o.qty
                ? "border-orange-500 bg-orange-50 shadow-lg scale-[1.01]"
                : "border-slate-200 bg-white hover:border-orange-300"
            }`}
          >
            <span className="absolute -top-3 right-4 rounded-full bg-red-600 px-3 py-0.5 text-[11px] font-black text-white shadow">
              {o.badge}
            </span>
            <span className="flex items-center gap-3">
              <span
                className={`flex h-6 w-6 items-center justify-center rounded-full border-2 ${
                  qty === o.qty ? "border-orange-500 bg-orange-500 text-white" : "border-slate-300"
                }`}
              >
                {qty === o.qty && <span className="text-xs font-black">✓</span>}
              </span>
              <span>
                <span className="block font-black text-slate-900">{o.label}</span>
                <span className="block text-xs font-bold text-green-600">{o.save}</span>
              </span>
            </span>
            <span className="text-left">
              <span className="block text-xl font-black text-orange-600">{formatPrice(o.price)}</span>
              <span className="block text-xs font-bold text-slate-400 line-through">{formatPrice(o.oldPrice)}</span>
            </span>
          </button>
        ))}
      </div>

      <div className="grid gap-3 md:grid-cols-2">
        <div className="md:col-span-2">
          <label className="mb-1 block text-sm font-black text-slate-700">الاسم الكامل *</label>
          <input
            value={form.fullName}
            onChange={(e) => setForm({ ...form, fullName: e.target.value })}
            placeholder="مثال: محمد العلوي"
            className="w-full rounded-xl border-2 border-slate-200 bg-white px-4 py-3 font-semibold outline-none transition focus:border-orange-500"
          />
        </div>
        <div>
          <label className="mb-1 block text-sm font-black text-slate-700">رقم الهاتف *</label>
          <input
            value={form.phone}
            onChange={(e) => setForm({ ...form, phone: e.target.value })}
            placeholder="06XXXXXXXX"
            inputMode="tel"
            dir="ltr"
            className="w-full rounded-xl border-2 border-slate-200 bg-white px-4 py-3 text-left font-bold outline-none transition focus:border-orange-500"
          />
        </div>
        <div>
          <label className="mb-1 block text-sm font-black text-slate-700">المدينة *</label>
          <select
            value={form.city}
            onChange={(e) => setForm({ ...form, city: e.target.value })}
            className="w-full rounded-xl border-2 border-slate-200 bg-white px-4 py-3 font-semibold outline-none transition focus:border-orange-500"
          >
            <option value="">— اختار المدينة —</option>
            {MOROCCAN_CITIES.map((c) => (
              <option key={c} value={c}>{c}</option>
            ))}
          </select>
        </div>
        <div className="md:col-span-2">
          <label className="mb-1 block text-sm font-black text-slate-700">العنوان الكامل *</label>
          <input
            value={form.address}
            onChange={(e) => setForm({ ...form, address: e.target.value })}
            placeholder="الحي، الزنقة، رقم الدار..."
            className="w-full rounded-xl border-2 border-slate-200 bg-white px-4 py-3 font-semibold outline-none transition focus:border-orange-500"
          />
        </div>
      </div>

      {error && (
        <div className="rounded-xl border border-red-200 bg-red-50 p-3 text-center text-sm font-black text-red-600">
          ⚠️ {error}
        </div>
      )}

      <button
        type="submit"
        disabled={loading}
        className="animate-pulse-glow fire-gradient w-full rounded-2xl py-4 text-xl font-black text-white shadow-xl transition hover:scale-[1.01] disabled:opacity-60"
      >
        {loading ? "⏳ جاري إرسال الطلب..." : `🔥 أكّد الطلب دابا — ${formatPrice(offer.price)}`}
      </button>
      <p className="text-center text-xs font-bold text-slate-500">
        💵 الدفع عند الاستلام &nbsp;•&nbsp; 🚚 التوصيل لجميع المدن &nbsp;•&nbsp; 🛡️ ضمان 6 أشهر
      </p>
    </form>
  );
}

/* ---------------- FAQ ---------------- */
const FAQS = [
  {
    q: "واش السخان خدام بالغاز ولا بالضو؟",
    a: "السخان ديالنا عالي الجودة وخدام بغاز البوطان (GPL) — يعني ما كيستهلكش الضو بزاف وكيعطيك ماء ساخن فوري بمجرد ما تحل الروبيني. اقتصادي وعملي للدار المغربية.",
  },
  {
    q: "شحال من دقيقة باش يسخن الماء؟",
    a: "هادا سخان فوري (Instantané) — ما كاينش انتظار! الماء كيسخن في ثواني معدودة منين كتحل الروبيني. 6 لتر في الدقيقة ديال الماء الساخن.",
  },
  {
    q: "واش التركيب ساهل؟",
    a: "نعم! التركيب ساهل وكيتركب على الحيط في الحمام ولا الكوزينة. كيحتاج غير الربط مع قنينة الغاز ومدخل ومخرج الماء. أي سبّاك (plombier) غادي يركبو ليك في أقل من ساعة.",
  },
  {
    q: "شنو الضمان اللي كاين؟",
    a: "السخان فيه ضمان 6 أشهر ضد عيوب الصنع، وهو مصنوع في المغرب بجودة عالية ومفحوص قطعة بقطعة قبل الشحن. إلا كان شي مشكل في التركيب ولا التشغيل، الفريق ديالنا كيعاونك.",
  },
  {
    q: "كيفاش نخلص؟",
    a: "الخلاص ساهل: الدفع عند الاستلام (COD). كتخلص غير منين توصلك السلعة لباب الدار وتشوفها بعينيك. التوصيل لجميع المدن المغربية.",
  },
  {
    q: "شحال كيدير التوصيل؟",
    a: "التوصيل مجاني 100% في هاد العرض ديال الشتاء! التوصيل كياخذ من 24 حتى 72 ساعة حسب المدينة ديالك.",
  },
];

function Faq() {
  const [open, setOpen] = useState<number | null>(0);
  return (
    <div className="space-y-3">
      {FAQS.map((f, i) => (
        <div key={i} className="overflow-hidden rounded-2xl border-2 border-slate-200 bg-white">
          <button
            type="button"
            onClick={() => setOpen(open === i ? null : i)}
            className="flex w-full items-center justify-between p-4 text-right font-black text-slate-900"
          >
            <span>{f.q}</span>
            <span className={`flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-orange-100 text-lg font-black text-orange-600 transition ${open === i ? "rotate-45" : ""}`}>
              +
            </span>
          </button>
          {open === i && <p className="border-t border-slate-100 p-4 pt-3 leading-relaxed text-slate-600">{f.a}</p>}
        </div>
      ))}
    </div>
  );
}

/* ---------------- Reviews ---------------- */
const REVIEWS = [
  { name: "الحاج العربي", city: "الدار البيضاء", stars: 5, text: "الله يعطيكم الصحة! السخان خدام مزيان والماء كيسخن في البلاصة. التركيب كان ساهل والثمن مناسب بزاف مقارنة مع السوق.", date: "قبل أسبوع" },
  { name: "أمينة ب.", city: "مراكش", stars: 5, text: "كنت كنعاني مع الماء البارد مع الدراري الصغار، دابا الحمد لله الماء ساخن في أي وقت. التوصيل وصل في يومين والتعامل راقي.", date: "قبل 5 أيام" },
  { name: "يوسف التازي", city: "فاس", stars: 5, text: "جودة ممتازة وصنع مغربي. جربتو هاد الشتاء كامل وما خسرش. كنصح بيه أي واحد ساكن في بلاصة باردة.", date: "قبل 3 أيام" },
  { name: "خديجة م.", city: "طنجة", stars: 4, text: "سخان زوين واقتصادي في الغاز. غير التركيب خدا شوية الوقت حيث السباك تعطل، ولكن المنتوج نفسو ممتاز.", date: "قبل يومين" },
  { name: "عبد الرحيم", city: "أكادير", stars: 5, text: "ثاني جهاز كنشري من عندكم، واحد ليا وواحد للوالدة. الثقة والجودة. الله يسهل عليكم.", date: "أمس" },
  { name: "سعيد بنعمر", city: "مكناس", stars: 5, text: "إفران والبرد القارس! هاد السخان نفعني بزاف هاد الشتاء. الماء ساخن وخا درجة الحرارة تحت الصفر برا.", date: "اليوم" },
];

function Stars({ n }: { n: number }) {
  return (
    <div className="flex gap-0.5" dir="ltr">
      {Array.from({ length: 5 }, (_, i) => (
        <span key={i} className={i < n ? "text-amber-400" : "text-slate-300"}>★</span>
      ))}
    </div>
  );
}

/* ================= MAIN LANDING ================= */
export default function Landing({ ordersToday }: { ordersToday: number }) {
  const heroRef = useRef<HTMLDivElement>(null);
  const orderQty = (q: number) => window.dispatchEvent(new CustomEvent("select-qty", { detail: q }));

  return (
    <div className="min-h-screen overflow-x-clip bg-slate-50">
      {/* Top marquee */}
      <div className="fire-gradient overflow-hidden py-2 text-white">
        <div className="flex w-max animate-[marquee_18s_linear_infinite] gap-8 whitespace-nowrap px-4 text-sm font-black" dir="rtl">
          {Array.from({ length: 6 }).map((_, i) => (
            <span key={i}>❄️ بمناسبة حلول فصل الشتاء: عرض قوي 🔥 سخان الغاز 6L عالي الجودة بـ {PRODUCT.price} درهم فقط بدل {PRODUCT.oldPrice} 🚚 التوصيل مجاني + الدفع عند الاستلام ❄️</span>
          ))}
        </div>
      </div>

      {/* Header */}
      <header className="sticky top-0 z-50 border-b border-white/10 bg-navy-950/95 text-white backdrop-blur">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-4 py-3">
          <div className="flex items-center gap-2">
            <div className="fire-gradient flex h-10 w-10 items-center justify-center rounded-xl text-xl font-black shadow">🔥</div>
            <div>
              <p className="text-lg font-black leading-none">BaytiPro <span className="text-orange-400">بيتي برو</span></p>
              <p className="text-[11px] font-semibold text-white/60">متجر رشيد 🏠 • جودة عالية ⭐</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <div className="hidden items-center gap-1 rounded-full bg-green-500/15 px-3 py-1.5 text-xs font-black text-green-400 md:flex">
              <span className="h-2 w-2 animate-pulse rounded-full bg-green-400" />
              متوفر — التوصيل لجميع المدن
            </div>
            <a href="#order" className="fire-gradient rounded-xl px-4 py-2.5 text-sm font-black shadow-lg transition hover:scale-105 md:px-6">
              🛒 طلب دابا
            </a>
          </div>
        </div>
      </header>

      {/* HERO */}
      <section ref={heroRef} className="winter-gradient relative overflow-hidden text-white">
        <Snowfall />
        <div className="pointer-events-none absolute -left-24 -top-24 h-96 w-96 rounded-full bg-orange-500/20 blur-3xl" />
        <div className="pointer-events-none absolute -bottom-32 -right-24 h-96 w-96 rounded-full bg-sky-400/20 blur-3xl" />

        <div className="relative mx-auto grid max-w-6xl items-center gap-8 px-4 py-10 md:grid-cols-2 md:py-16">
          {/* Text */}
          <div className="text-center md:text-right">
            <div className="inline-flex items-center gap-2 rounded-full border border-orange-400/40 bg-orange-500/15 px-4 py-1.5 text-sm font-black text-orange-300">
              ❄️ عرض الشتاء الذهبي — كمية محدودة ❄️
            </div>
            <h1 className="mt-4 text-3xl font-black leading-[1.35] md:text-5xl md:leading-[1.3]">
              صافي من البرد! 🥶
              <br />
              <span className="bg-gradient-to-l from-amber-300 via-orange-400 to-red-400 bg-clip-text text-transparent">
                ماء ساخن فوري
              </span>{" "}
              في دارك هاد الشتاء 🔥
            </h1>
            <p className="mx-auto mt-4 max-w-lg text-base font-semibold leading-relaxed text-sky-100/90 md:mx-0 md:text-lg">
              سخان الماء الغازي الفوري <b className="text-white">6L عالي الجودة ⭐</b> — صنع في المغرب 🇲🇦
              <br />
              يسخن الماء في <b className="text-amber-300">ثواني</b>، اقتصادي في الغاز، وبضمان <b className="text-amber-300">6 أشهر</b>.
            </p>

            {/* rating */}
            <div className="mt-4 flex items-center justify-center gap-2 md:justify-start">
              <Stars n={5} />
              <span className="text-sm font-black">{PRODUCT.rating}/5</span>
              <span className="text-xs font-semibold text-white/60">(+{PRODUCT.reviewsCount} تقييم • +{PRODUCT.soldCount} زبون راضي)</span>
            </div>

            {/* price card */}
            <div className="mx-auto mt-5 max-w-md rounded-3xl border-2 border-orange-400/50 bg-white/10 p-5 backdrop-blur md:mx-0">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-bold text-white/60 line-through">{formatPrice(PRODUCT.oldPrice)}</p>
                  <p className="text-4xl font-black text-amber-300 md:text-5xl">{PRODUCT.price} <span className="text-xl">درهم</span></p>
                  <p className="mt-1 inline-block rounded-full bg-red-600 px-3 py-0.5 text-xs font-black">خصم {Math.round((1 - PRODUCT.price / PRODUCT.oldPrice) * 100)}% — وفّر {PRODUCT.oldPrice - PRODUCT.price} درهم 🎉</p>
                </div>
                <div className="text-center">
                  <p className="mb-2 text-xs font-black text-white/70">⏳ العرض كيسالي في:</p>
                  <CountdownBox dark />
                </div>
              </div>
              <div className="mt-3 flex items-center gap-2 rounded-xl bg-red-600/20 p-2.5 text-xs font-black text-red-200">
                <span className="animate-flicker">🔥</span>
                غير {PRODUCT.stockLeft} جهاز باقي في المخزون — الطلبات كتار هاد الشتاء!
                <span className="mr-auto rounded-full bg-red-600 px-2 py-0.5 text-[10px] text-white">اليوم: +{ordersToday} طلب</span>
              </div>
            </div>

            <div className="mt-5 flex flex-col gap-3 sm:flex-row sm:justify-center md:justify-start">
              <a href="#order" className="animate-pulse-glow fire-gradient rounded-2xl px-8 py-4 text-center text-xl font-black shadow-2xl transition hover:scale-105">
                🛒 اطلب دابا — الدفع عند الاستلام
              </a>
              <a href="#features" className="rounded-2xl border-2 border-white/25 px-8 py-4 text-center text-lg font-black text-white/90 transition hover:bg-white/10">
                اكتشف المميزات 👇
              </a>
            </div>
            <p className="mt-3 text-xs font-bold text-white/50">✓ بدون دفع مسبق &nbsp; ✓ عاين السلعة عاد خلص &nbsp; ✓ توصيل سريع</p>
          </div>

          {/* Product visual */}
          <div className="relative mx-auto w-full max-w-md">
            <div className="absolute inset-0 -z-0 scale-90 rounded-full bg-orange-500/30 blur-3xl" />
            <div className="animate-bounce-soft relative overflow-hidden rounded-[2rem] border-2 border-white/20 shadow-2xl">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src="/images/heater-hero.png" alt="سخان الماء الغازي الفوري 6L عالي الجودة" className="h-auto w-full object-cover" />
              <div className="absolute left-3 top-3 rotate-[-8deg] rounded-2xl bg-red-600 px-4 py-2 text-center shadow-xl">
                <p className="text-2xl font-black leading-none">-{Math.round((1 - PRODUCT.price / PRODUCT.oldPrice) * 100)}%</p>
                <p className="text-[11px] font-black">تخفيض الشتاء</p>
              </div>
              <div className="absolute bottom-3 right-3 flex items-center gap-1 rounded-full bg-navy-950/90 px-3 py-1.5 text-xs font-black backdrop-blur">
                🇲🇦 صنع في المغرب • ضمان 6 أشهر 🛡️
              </div>
            </div>
            {/* floating chips */}
            <div className="animate-wiggle absolute -right-2 top-8 rounded-2xl bg-white p-3 text-center text-slate-900 shadow-2xl md:-right-6">
              <p className="text-2xl">⚡</p>
              <p className="text-xs font-black">تسخين فوري</p>
              <p className="text-[10px] font-bold text-slate-500">6L / دقيقة</p>
            </div>
            <div className="animate-wiggle absolute -left-2 bottom-16 rounded-2xl bg-white p-3 text-center text-slate-900 shadow-2xl md:-left-6" style={{ animationDelay: "1s" }}>
              <p className="text-2xl">🔥</p>
              <p className="text-xs font-black">غاز البوطان</p>
              <p className="text-[10px] font-bold text-slate-500">اقتصادي</p>
            </div>
          </div>
        </div>

        {/* trust strip */}
        <div className="relative border-t border-white/10 bg-black/20">
          <div className="mx-auto grid max-w-6xl grid-cols-2 gap-2 px-4 py-4 text-center md:grid-cols-4">
            {[
              { e: "🚚", t: "التوصيل مجاني", s: "لجميع المدن المغربية" },
              { e: "💵", t: "الدفع عند الاستلام", s: "خلص منين توصلك" },
              { e: "🛡️", t: "ضمان 6 أشهر", s: "جودة مفحوصة ⭐" },
              { e: "🇲🇦", t: "صنع في المغرب", s: "جودة مضمونة" },
            ].map((x) => (
              <div key={x.t} className="flex items-center justify-center gap-2 rounded-xl bg-white/5 px-2 py-2">
                <span className="text-2xl">{x.e}</span>
                <span className="text-right">
                  <span className="block text-sm font-black">{x.t}</span>
                  <span className="block text-[11px] font-semibold text-white/60">{x.s}</span>
                </span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* PAIN */}
      <section className="mx-auto max-w-6xl px-4 py-12">
        <div className="text-center">
          <p className="text-sm font-black text-sky-600">🥶 معاناة كل شتاء في المغرب...</p>
          <h2 className="mt-2 text-2xl font-black text-slate-900 md:text-4xl">واش كتعرف هاد المواقف؟</h2>
        </div>
        <div className="mt-8 grid gap-4 md:grid-cols-3">
          {[
            { e: "🥶", t: "الدوش بالماء البارد", d: "في الصباح الباكر الماء بحال الثلج، والدوش كيولي عذاب يومي ليك ولوليداتك." },
            { e: "⏰", t: "تسخين الماء بالبراد", d: "كل مرة تسخن الماء في الكوكوت ولا البراد باش تغسل ولا تدوش؟ صافي سالات هاد المعاناة!" },
            { e: "💸", t: "فاتورة الضو الغالية", d: "السخانات الكهربائية كتاكل الضو بزاف والفاتورة كتطلع للسما كل شهر." },
          ].map((x) => (
            <div key={x.t} className="rounded-3xl border-2 border-sky-100 bg-white p-6 text-center shadow-sm transition hover:-translate-y-1 hover:shadow-xl">
              <p className="text-5xl">{x.e}</p>
              <h3 className="mt-3 text-lg font-black text-slate-900">{x.t}</h3>
              <p className="mt-2 text-sm leading-relaxed text-slate-600">{x.d}</p>
            </div>
          ))}
        </div>
        <div className="mx-auto mt-6 max-w-3xl rounded-3xl bg-gradient-to-l from-orange-500 to-red-600 p-6 text-center text-white shadow-xl">
          <p className="text-xl font-black md:text-2xl">✅ الحل: سخان الغاز 6L عالي الجودة — ماء ساخن فوري بمجرد ما تحل الروبيني!</p>
          <p className="mt-1 text-sm font-semibold text-white/85">بلا انتظار • بلا فاتورة ضو غالية • بلا معاناة</p>
        </div>
      </section>

      {/* FEATURES */}
      <section id="features" className="bg-white py-12">
        <div className="mx-auto max-w-6xl px-4">
          <div className="text-center">
            <p className="text-sm font-black text-orange-600">⭐ علاش هاد السخان هو الاختيار رقم 1 في المغرب؟</p>
            <h2 className="mt-2 text-2xl font-black text-slate-900 md:text-4xl">مميزات كتخليه مختلف 🔥</h2>
          </div>
          <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {[
              { e: "⚡", t: "تسخين فوري Instantané", d: "ماء ساخن في ثواني! 6 لتر في الدقيقة — دوش، كوزينة، وضوء... كلشي في البلاصة." },
              { e: "🔥", t: "اقتصادي في الغاز", d: "خدام بغاز البوطان (GPL) وكيشعل غير منين كتحل الماء — يعني اقتصاد حقيقي." },
              { e: "🇲🇦", t: "صنع في المغرب", d: "مصنوع محلياً بمعايير الجودة، وقطع الغيار متوفرة والصيانة ساهلة." },
              { e: "🛡️", t: "ضمان 6 أشهر + جودة ممتازة", d: "ضمان حقيقي ضد عيوب الصنع + فحص الجودة قطعة بقطعة قبل الشحن + أنظمة أمان ضد الحرارة الزائدة." },
              { e: "🎛️", t: "تحكم ساهل", d: "جوج مقابض بسيطة: واحد للحرارة وواحد لضغط الماء. حتى الوالدة غادي تعرف تستعملو!" },
              { e: "📦", t: "حجم صغير وأنيق", d: "تصميم مدمج كيتعلق على الحيط وما كياخدش بلاصة — مثالي للحمام والكوزينة." },
            ].map((x) => (
              <div key={x.t} className="group rounded-3xl border-2 border-slate-100 bg-slate-50 p-6 transition hover:border-orange-300 hover:bg-orange-50">
                <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-white text-3xl shadow transition group-hover:scale-110">{x.e}</div>
                <h3 className="mt-4 font-black text-slate-900">{x.t}</h3>
                <p className="mt-1.5 text-sm leading-relaxed text-slate-600">{x.d}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* SHOWCASE */}
      <section className="winter-gradient relative overflow-hidden py-12 text-white">
        <Snowfall count={14} />
        <div className="relative mx-auto max-w-6xl px-4">
          <div className="grid items-center gap-8 md:grid-cols-2">
            <div className="overflow-hidden rounded-3xl border-2 border-white/15 shadow-2xl">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src="/images/heater-bathroom.jpg" alt="سخان الغاز مركب في الحمام" className="h-72 w-full object-cover transition hover:scale-105 md:h-96" />
            </div>
            <div>
              <p className="text-sm font-black text-orange-300">🏠 مثالي لدارك</p>
              <h2 className="mt-2 text-2xl font-black md:text-3xl">تخيل هاد الشتاء: دوش ساخن في أي وقت! 🚿</h2>
              <ul className="mt-5 space-y-3">
                {[
                  "دوش ساخن للعائلة كاملة بلا ما تسنى",
                  "غسيل المواعن بالماء الساخن في الكوزينة",
                  "الوضوء بالماء الدافئ في الفجر 🕌",
                  "الدراري الصغار دافيين ومرتاحين 👶",
                ].map((t) => (
                  <li key={t} className="flex items-center gap-3 rounded-2xl bg-white/10 p-3 font-bold">
                    <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-green-500 text-white">✓</span>
                    {t}
                  </li>
                ))}
              </ul>
              <div className="mt-5 grid grid-cols-3 gap-2 text-center">
                {[
                  { v: "6L", l: "لتر / دقيقة" },
                  { v: "ثواني", l: "وقت التسخين" },
                  { v: "GPL", l: "غاز البوطان" },
                ].map((s) => (
                  <div key={s.l} className="rounded-2xl border border-white/15 bg-white/5 p-3">
                    <p className="text-xl font-black text-amber-300">{s.v}</p>
                    <p className="text-[11px] font-bold text-white/60">{s.l}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* COMPARISON */}
      <section className="mx-auto max-w-4xl px-4 py-12">
        <h2 className="text-center text-2xl font-black text-slate-900 md:text-3xl">⚖️ قارن بنفسك: سخان BaytiPro vs السخانات العادية</h2>
        <div className="mt-6 overflow-hidden rounded-3xl border-2 border-slate-200 bg-white shadow-lg">
          <table className="w-full text-center text-sm">
            <thead>
              <tr className="bg-navy-950 text-white">
                <th className="p-3 text-right font-black">الميزة</th>
                <th className="fire-gradient p-3 font-black">🔥 BaytiPro 6L</th>
                <th className="p-3 font-bold text-white/60">سخان عادي</th>
              </tr>
            </thead>
            <tbody className="font-semibold">
              {[
                ["وقت التسخين", "ثواني ⚡", "30-60 دقيقة"],
                ["استهلاك الطاقة", "غاز اقتصادي 💰", "كهرباء غالية"],
                ["الضمان", "6 أشهر 🛡️", "بدون ضمان"],
                ["الجودة", "ممتازة ومفحوصة ⭐", "عادية"],
                ["الصنع", "المغرب 🇲🇦", "مستورد"],
                ["التركيب", "ساهل و سريع", "معقد"],
                ["الثمن", `${formatPrice(PRODUCT.price)} 🎉`, "+1500 درهم"],
              ].map((r, i) => (
                <tr key={r[0]} className={i % 2 ? "bg-slate-50" : ""}>
                  <td className="p-3 text-right font-black">{r[0]}</td>
                  <td className="bg-orange-50 p-3 font-black text-orange-700">{r[1]}</td>
                  <td className="p-3 text-slate-500">{r[2]}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>

      {/* STEAM BANNER */}
      <section className="relative overflow-hidden">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img src="/images/hot-shower.jpg" alt="دوش ساخن" className="h-64 w-full object-cover md:h-80" />
        <div className="absolute inset-0 flex flex-col items-center justify-center bg-navy-950/60 px-4 text-center text-white">
          <p className="text-2xl font-black md:text-4xl">الدفء كيبدا من هنا 🔥❄️</p>
          <p className="mt-2 font-bold text-white/80">+{PRODUCT.soldCount} أسرة مغربية كيدوشو بالماء الساخن هاد الشتاء</p>
          <a href="#order" className="fire-gradient mt-4 rounded-2xl px-8 py-3 text-lg font-black shadow-xl transition hover:scale-105">
            انضم ليهم دابا 👇
          </a>
        </div>
      </section>

      {/* REVIEWS */}
      <section className="mx-auto max-w-6xl px-4 py-12">
        <div className="text-center">
          <div className="inline-flex items-center gap-2 rounded-full bg-amber-100 px-4 py-1.5 text-sm font-black text-amber-700">
            ⭐ {PRODUCT.rating}/5 من +{PRODUCT.reviewsCount} تقييم حقيقي
          </div>
          <h2 className="mt-3 text-2xl font-black text-slate-900 md:text-4xl">شنو قالو الزبناء ديالنا؟ 💬</h2>
        </div>
        <div className="mt-8 grid gap-4 md:grid-cols-3">
          {REVIEWS.map((r) => (
            <div key={r.name} className="flex flex-col rounded-3xl border-2 border-slate-100 bg-white p-5 shadow-sm transition hover:shadow-lg">
              <Stars n={r.stars} />
              <p className="mt-3 flex-1 text-sm leading-relaxed text-slate-700">&ldquo;{r.text}&rdquo;</p>
              <div className="mt-4 flex items-center gap-3 border-t border-slate-100 pt-3">
                <div className="fire-gradient flex h-10 w-10 items-center justify-center rounded-full text-sm font-black text-white">
                  {r.name[0]}
                </div>
                <div>
                  <p className="text-sm font-black">{r.name} <span className="font-bold text-slate-400">• {r.city}</span></p>
                  <p className="text-[11px] font-bold text-green-600">✓ عملية شراء مؤكدة • {r.date}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* OFFER + ORDER */}
      <section id="order" className="scroll-mt-20 bg-gradient-to-b from-orange-50 to-white py-12">
        <div className="mx-auto max-w-4xl px-4">
          <div className="text-center">
            <p className="inline-block rounded-full bg-red-600 px-4 py-1.5 text-sm font-black text-white shadow">🔥 عرض الشتاء — الكمية محدودة!</p>
            <h2 className="mt-3 text-2xl font-black text-slate-900 md:text-4xl">عمّر الاستمارة و توصلك السلعة لباب الدار 📦</h2>
            <p className="mt-2 font-bold text-slate-600">الدفع عند الاستلام 💵 • التوصيل مجاني 🚚 • بلا التزام</p>
            <div className="mx-auto mt-4 max-w-xs">
              <CountdownBox />
            </div>
          </div>

          <div className="mt-6 grid gap-6 md:grid-cols-5">
            <div className="md:col-span-3 rounded-3xl border-2 border-orange-200 bg-white p-5 shadow-xl md:p-6">
              <OrderForm />
            </div>
            <div className="space-y-4 md:col-span-2">
              <div className="winter-gradient relative overflow-hidden rounded-3xl p-5 text-white shadow-xl">
                <Snowfall count={8} />
                <p className="relative text-sm font-black text-orange-300">🎁 مع كل طلب هاد الأسبوع:</p>
                <ul className="relative mt-3 space-y-2 text-sm font-bold">
                  <li className="flex gap-2">✅ <span>التوصيل <b className="text-amber-300">مجاني</b> لجميع المدن</span></li>
                  <li className="flex gap-2">✅ <span>دليل التركيب بالعربية <b className="text-amber-300">مجاناً</b></span></li>
                  <li className="flex gap-2">✅ <span>متابعة هاتفية <b className="text-amber-300">مجانية</b> بعد الشراء</span></li>
                  <li className="flex gap-2">✅ <span>ضمان <b className="text-amber-300">6 أشهر</b> مكتوب</span></li>
                  <li className="flex gap-2">✅ <span>فحص <b className="text-amber-300">الجودة</b> قبل الشحن ⭐</span></li>
                </ul>
              </div>
              <div className="rounded-3xl border-2 border-green-200 bg-green-50 p-5">
                <p className="font-black text-green-800">🛡️ ضمان الثقة 100%</p>
                <p className="mt-1 text-sm leading-relaxed text-green-700">
                  عاين المنتوج ملي يوصلك، وإلا ما عجبكش ولا فيه شي عيب مصنعي، كنرجعو ليك فلوسك. بلا أسئلة بلا صداع!
                </p>
              </div>
              <div className="rounded-3xl border-2 border-slate-200 bg-white p-5 text-center">
                <p className="text-sm font-black text-slate-700">📞 محتاج تعاون؟ عيّط لينا:</p>
                <a href="tel:+212651840540" dir="ltr" className="mt-1 block text-2xl font-black text-orange-600">{OWNER_PHONE_DISPLAY}</a>
                <a
                  href={`${OWNER_WHATSAPP_LINK}?text=${encodeURIComponent("السلام عليكم 👋 عندي سؤال على سخان الغاز 6L")}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="mt-3 flex items-center justify-center gap-2 rounded-2xl bg-[#25D366] px-4 py-2.5 text-sm font-black text-white shadow transition hover:bg-[#1fb857]"
                >
                  💬 صيفط لينا واتساب
                </a>
                <p className="mt-2 text-xs font-bold text-slate-400">من الاثنين للسبت • 9h - 19h</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section className="mx-auto max-w-3xl px-4 py-12">
        <h2 className="text-center text-2xl font-black text-slate-900 md:text-3xl">❓ الأسئلة اللي كتتعود بزاف</h2>
        <div className="mt-6"><Faq /></div>
      </section>

      {/* FINAL CTA */}
      <section className="winter-gradient relative overflow-hidden py-12 text-center text-white">
        <Snowfall count={18} />
        <div className="relative mx-auto max-w-2xl px-4">
          <p className="text-5xl">🔥❄️🔥</p>
          <h2 className="mt-3 text-2xl font-black md:text-4xl">ما تخليش البرد يغلبك هاد الشتاء!</h2>
          <p className="mt-2 font-bold text-white/75">العرض محدود بالكمية — ملي تسالي الكمية كيرجع الثمن الأصلي (1299 درهم)</p>
          <div className="mx-auto mt-5 flex max-w-md flex-col gap-2">
            <button onClick={() => orderQty(1)} className="animate-pulse-glow fire-gradient rounded-2xl px-8 py-4 text-xl font-black shadow-2xl transition hover:scale-105">
              🛒 اطلب جهاز واحد — {formatPrice(QUANTITY_OFFERS[0].price)}
            </button>
            <button onClick={() => orderQty(2)} className="rounded-2xl border-2 border-amber-400/60 bg-amber-400/10 px-8 py-3 font-black text-amber-300 transition hover:bg-amber-400/20">
              👨‍👩‍👧 عرض العائلة: جهازين بـ {formatPrice(QUANTITY_OFFERS[1].price)} (وفّر {QUANTITY_OFFERS[1].oldPrice - QUANTITY_OFFERS[1].price}!)
            </button>
          </div>
          <p className="mt-3 text-xs font-bold text-white/50">💵 الدفع عند الاستلام • 🚚 توصيل مجاني • 🛡️ ضمان 6 أشهر</p>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-navy-950 py-8 text-white/70">
        <div className="mx-auto max-w-6xl px-4 text-center">
          <p className="text-lg font-black text-white">🏠 BaytiPro — بيتي برو 🇲🇦</p>
          <p className="mt-1 text-sm font-semibold">سخان الماء الغازي الفوري 6L — متجر رشيد • صنع في المغرب بفخر</p>
          <div className="mt-3 flex items-center justify-center gap-4 text-xs font-bold">
            <span>🚚 توصيل لجميع المدن</span>
            <span>•</span>
            <span>💵 الدفع عند الاستلام</span>
            <span>•</span>
            <span>🛡️ ضمان 6 أشهر</span>
          </div>
          <p className="mt-4 text-[11px]">© 2026 BaytiPro — متجر رشيد — جميع الحقوق محفوظة</p>
        </div>
      </footer>

      {/* Sticky mobile CTA */}
      <div className="fixed bottom-0 left-0 right-0 z-50 border-t border-white/10 bg-navy-950/97 p-3 backdrop-blur md:hidden">
        <div className="flex items-center gap-3">
          <div className="text-white">
            <p className="text-[11px] font-bold text-white/50 line-through">{formatPrice(PRODUCT.oldPrice)}</p>
            <p className="text-xl font-black text-amber-300">{formatPrice(PRODUCT.price)}</p>
          </div>
          <a href="#order" className="fire-gradient flex-1 rounded-xl py-3 text-center text-lg font-black text-white shadow-lg">
            🛒 اطلب دابا
          </a>
        </div>
      </div>
      <div className="h-20 md:hidden" />

      {/* Floating WhatsApp */}
      <a
        href={`${OWNER_WHATSAPP_LINK}?text=${encodeURIComponent(`السلام عليكم 👋 بغيت نستفسر على عرض سخان الغاز 6L بـ ${PRODUCT.price} درهم 🔥`)}`}
        target="_blank"
        rel="noopener noreferrer"
        aria-label="تواصل عبر واتساب"
        className="fixed bottom-24 left-3 z-50 flex h-14 w-14 items-center justify-center rounded-full bg-[#25D366] text-white shadow-2xl transition hover:scale-110 md:bottom-6 md:left-6 md:h-16 md:w-16"
      >
        <span className="absolute inset-0 animate-ping rounded-full bg-[#25D366] opacity-25" />
        <svg viewBox="0 0 24 24" className="relative h-7 w-7 fill-current md:h-8 md:w-8" aria-hidden>
          <path d="M17.5 14.4c-.3-.15-1.76-.87-2.03-.97-.27-.1-.47-.15-.67.15-.2.3-.77.97-.94 1.17-.17.2-.35.22-.65.07-.3-.15-1.26-.46-2.4-1.48-.88-.79-1.48-1.76-1.65-2.06-.17-.3-.02-.46.13-.61.14-.13.3-.35.45-.52.15-.17.2-.3.3-.5.1-.2.05-.37-.02-.52-.08-.15-.67-1.62-.92-2.22-.24-.58-.49-.5-.67-.51h-.57c-.2 0-.52.07-.8.37-.27.3-1.04 1.02-1.04 2.5 0 1.47 1.07 2.9 1.22 3.1.15.2 2.1 3.2 5.1 4.49.71.31 1.27.49 1.7.63.72.23 1.37.2 1.88.12.58-.09 1.76-.72 2-1.42.25-.7.25-1.29.18-1.42-.08-.13-.28-.2-.58-.35M12.05 21.79h-.01a9.87 9.87 0 0 1-5.03-1.38l-.36-.21-3.74.98 1-3.65-.24-.37a9.85 9.85 0 1 1 8.38 4.63m8.42-18.29A11.82 11.82 0 0 0 12.04 0C5.5 0 .16 5.34.16 11.9c0 2.1.55 4.14 1.59 5.95L.06 24l6.3-1.65a11.9 11.9 0 0 0 5.68 1.45h.01c6.55 0 11.89-5.34 11.89-11.9 0-3.18-1.24-6.16-3.47-8.4" />
        </svg>
      </a>

      <SocialToast />
    </div>
  );
}
